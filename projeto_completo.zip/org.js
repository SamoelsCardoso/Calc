// redwashere
// Aguarda que todo o esqueleto HTML esteja carregado e analisado pelo navegador antes de executar o script
document.addEventListener("DOMContentLoaded", () => {
    // Captura o elemento do formulário principal de cálculos
    const form = document.getElementById("calculator-form");
    // Captura o elemento de seleção (dropdown) que define o tipo de fórmula/categoria
    const calcType = document.getElementById("calc-type");
    // Captura o contentor HTML onde os campos de texto e inputs específicos serão gerados dinamicamente
    const dynamicFields = document.getElementById("dynamic-fields");
    // Captura o elemento de texto onde o resultado final da fórmula será impresso
    const resultBox = document.getElementById("result");
    // Captura o elemento de cabeçalho que exibe o subtítulo ou nome da operação atual
    const subtitle = document.getElementById("subtitle");

    // Verifica se algum dos elementos cruciais da interface está em falta na página
    if (!form || !calcType || !dynamicFields || !resultBox || !subtitle) {
        // Regista uma mensagem de erro no painel de desenvolvimento do navegador
        console.error("Elementos da interface não encontrados.");
        // Interrompe a inicialização do script para evitar falhas em cascata
        return;
    }

    // ── sistema de logging por código no console ───────────────────────────────
    // Cada ação relevante concluída emite um log com um código numérico fixo.
    // O significado de cada código está descrito em CONSOLE_CODES (ver tabela
    // enviada junto com esta alteração).
    const CONSOLE_CODES = {
        1: "Cálculo concluído",
        2: "Resultado salvo no histórico",
        3: "Histórico renderizado na tela",
        4: "Histórico limpo pelo usuário",
        5: "Campos dinâmicos re-renderizados (mudança de tipo/categoria)",
        6: "Script inicializado com sucesso"
    };
    function logCode(code, extra = "") {
        console.log(`[code ${code}] ${CONSOLE_CODES[code]}${extra ? " — " + extra : ""}`);
    }

    // ── sistema de "passo a passo" ──────────────────────────────────────────
    // Guarda os passos do último cálculo feito (fórmula usada, valores
    // preenchidos e resultado). É recalculado a cada vez que calculate() roda
    // e mostrado escondido atrás do botão "Ver passo a passo" (renderSteps).
    let lastSteps = [];
    let modularTokens = []; // tokens do construtor de fórmulas modular (blocos clicados pelo usuário)

    // ── acessibilidade / personalização (tema, tamanho de fonte, animações, voz) ──
    const A11Y_KEY = "calcA11ySettings";
    const defaultA11ySettings = { theme: "dark", fontSize: "md", reducedMotion: false, autoSpeak: false };

    function loadA11ySettings() {
        try {
            const data = localStorage.getItem(A11Y_KEY);
            return data ? { ...defaultA11ySettings, ...JSON.parse(data) } : { ...defaultA11ySettings };
        } catch {
            return { ...defaultA11ySettings };
        }
    }

    let a11ySettings = loadA11ySettings();

    // Aplica as configurações atuais no <html> (atributos lidos pelo CSS) e atualiza os controles do painel
    function applyA11ySettings() {
        const root = document.documentElement;
        root.setAttribute("data-theme", a11ySettings.theme);
        root.setAttribute("data-font-size", a11ySettings.fontSize);
        root.setAttribute("data-reduced-motion", a11ySettings.reducedMotion ? "true" : "false");

        // troca o ícone da aba (favicon) junto com o tema — gatinho com Σ em cada tema
        const favicon = document.getElementById("site-favicon");
        if (favicon) favicon.href = `favicon-${a11ySettings.theme}.ico`;

        document.querySelectorAll(".a11y-option[data-setting]").forEach(btn => {
            const isActive = a11ySettings[btn.dataset.setting] === btn.dataset.value;
            btn.setAttribute("aria-pressed", String(isActive));
        });
        const motionCheckbox = document.getElementById("a11y-reduced-motion");
        if (motionCheckbox) motionCheckbox.checked = a11ySettings.reducedMotion;
        const speakCheckbox = document.getElementById("a11y-auto-speak");
        if (speakCheckbox) speakCheckbox.checked = a11ySettings.autoSpeak;
    }

    function saveA11ySettings() {
        try { localStorage.setItem(A11Y_KEY, JSON.stringify(a11ySettings)); } catch { /* localStorage indisponível: só não persiste */ }
        applyA11ySettings();
    }

    // Fala um texto em voz alta usando a Web Speech API do navegador (sem biblioteca externa)
    function speakText(text) {
        if (!("speechSynthesis" in window) || !text) return;
        window.speechSynthesis.cancel(); // corta qualquer fala anterior em andamento
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "pt-BR";
        window.speechSynthesis.speak(utterance);
    }
    let lastTheory = "";
    const stepsToggleBtn = document.getElementById("toggle-steps");
    const stepsListEl = document.getElementById("steps-list");
    const theoryEl = document.getElementById("theory-text");

    // Adiciona uma linha ao passo a passo do cálculo atual (fórmula, substituição, conta parcial etc.)
    function st(text) { lastSteps.push(text); }

    // Esconde e zera o passo a passo e a explicação teórica (chamado sempre que o tipo de cálculo muda)
    function hideSteps() {
        lastSteps = [];
        lastTheory = "";
        if (stepsToggleBtn) { stepsToggleBtn.hidden = true; stepsToggleBtn.textContent = "Ver passo a passo"; stepsToggleBtn.setAttribute("aria-expanded", "false"); }
        if (stepsListEl) { stepsListEl.classList.remove("open"); stepsListEl.innerHTML = ""; }
        if (theoryEl) { theoryEl.hidden = true; theoryEl.textContent = ""; }
    }

    // Mostra a explicação teórica (sempre visível, sem precisar clicar em nada)
    function renderTheory(text) {
        if (!theoryEl) return;
        if (!text) { theoryEl.hidden = true; theoryEl.textContent = ""; return; }
        theoryEl.textContent = text;
        theoryEl.hidden = false;
    }

    // Mostra o botão e monta a listinha de passos (continua fechada, com animação, até o usuário clicar)
    function renderSteps(steps) {
        if (!stepsToggleBtn || !stepsListEl) return;
        if (!steps || steps.length === 0) { hideSteps(); return; }
        stepsListEl.innerHTML = steps.map(s => `<li>${escapeHtml(s)}</li>`).join("");
        stepsListEl.classList.remove("open");
        stepsToggleBtn.hidden = false;
        stepsToggleBtn.textContent = "Ver passo a passo";
        stepsToggleBtn.setAttribute("aria-expanded", "false");
    }

    // ── infraestrutura do gráfico (Chart.js) ────────────────────────────────────
    // chartCard/chartCanvas/chartTitleEl são opcionais: se o HTML não tiver esses
    // elementos, ou se o Chart.js não tiver carregado, o gráfico simplesmente não
    // aparece — o resto da calculadora continua funcionando normalmente.
    const chartCard = document.getElementById("chart-card");
    const chartCanvas = document.getElementById("result-chart");
    const chartTitleEl = document.getElementById("chart-title");
    let chartInstance = null;

    // Esconde e destrói o gráfico atual (chamado sempre que o tipo de cálculo
    // muda ou quando o cálculo em questão não tem gráfico associado)
    function hideChart() {
        if (chartInstance) { chartInstance.destroy(); chartInstance = null; }
        if (chartCard) chartCard.hidden = true;
    }

    // Paleta de cores reaproveitada do CSS (second.css), pra o gráfico combinar com o tema escuro
    function chartTheme() {
        if (a11ySettings.theme === "light") {
            return { grid: "#d8d5cc", tick: "#55534a", accent: "#a8720a", accent2: "#c2540a", green: "#1e7d32" };
        }
        if (a11ySettings.theme === "contrast") {
            return { grid: "#000000", tick: "#000000", accent: "#0057d8", accent2: "#d84b00", green: "#00701f" };
        }
        return { grid: "#333333", tick: "#bcbcbc", accent: "#f2c94c", accent2: "#ff7a00", green: "#7ef0a0" };
    }

    // Verifica se um conjunto de valores realmente cobre o zero (min ≤ 0 ≤ max).
    // Só faz sentido cruzar os eixos no (0,0) quando o zero está de fato na
    // faixa visível — senão o eixo "sai da tela" (foi o que aconteceu com
    // valores na casa dos bilhões: o zero fica longe demais pra aparecer).
    function spansZero(values) {
        if (!values || !values.length) return false;
        let min = Infinity, max = -Infinity;
        for (const v of values) { if (v === null || Number.isNaN(v)) continue; if (v < min) min = v; if (v > max) max = v; }
        return min <= 0 && max >= 0;
    }

    // crossX = eixo horizontal cruza no y=0 (só se os valores de Y cobrirem o zero)
    // crossY = eixo vertical cruza no x=0 (só se os valores de X cobrirem o zero)
    // Quando não cobre, volta pro comportamento tradicional de borda (bottom/left).
    function baseScales({ crossX = false, crossY = false } = {}) {
        const t = chartTheme();
        return {
            x: { position: crossX ? { y: 0 } : undefined, grid: { color: t.grid }, ticks: { color: t.tick } },
            y: { position: crossY ? { x: 0 } : undefined, grid: { color: t.grid }, ticks: { color: t.tick } }
        };
    }

    function baseLegend() {
        return { labels: { color: chartTheme().tick } };
    }

    // Desenha (ou redesenha) o gráfico com a configuração do Chart.js recebida.
    // Envolvido em try/catch: se o Chart.js falhar por qualquer motivo, o gráfico
    // só fica escondido — o resultado do cálculo e o histórico continuam funcionando normalmente.
    function drawChart(title, config) {
        if (!chartCard || !chartCanvas || typeof Chart === "undefined") return;
        if (chartInstance) { chartInstance.destroy(); chartInstance = null; }
        if (chartTitleEl) chartTitleEl.textContent = title;
        chartCard.hidden = false;
        try {
            chartInstance = new Chart(chartCanvas.getContext("2d"), config);
        } catch (err) {
            console.error("Não foi possível desenhar o gráfico:", err);
            chartInstance = null;
            chartCard.hidden = true;
        }
    }

    // ── gráfico: Bhaskara — desenha a parábola e marca as raízes reais, se houver
    function chartBhaskara(a, b, c, delta) {
        const t = chartTheme();
        const vertexX = -b / (2 * a);
        const spread = delta >= 0
            ? Math.max(Math.abs(Math.sqrt(delta) / (2 * a)) * 2.5, 1)
            : Math.max(Math.abs(vertexX), 5);
        const min = vertexX - spread, max = vertexX + spread;
        const steps = 60;
        const points = [];
        for (let i = 0; i <= steps; i++) {
            const x = min + ((max - min) * i) / steps;
            points.push({ x, y: a * x * x + b * x + c });
        }
        const datasets = [{
            label: "f(x) = ax² + bx + c",
            data: points, borderColor: t.accent, backgroundColor: "transparent",
            borderWidth: 2, pointRadius: 0, tension: 0.15
        }];
        if (delta >= 0) {
            const x1 = (-b + Math.sqrt(delta)) / (2 * a);
            const x2 = (-b - Math.sqrt(delta)) / (2 * a);
            datasets.push({
                label: "Raízes", data: [{ x: x1, y: 0 }, { x: x2, y: 0 }],
                borderColor: t.accent2, backgroundColor: t.accent2, pointRadius: 5, showLine: false
            });
        }
        const sc = baseScales({ crossX: spansZero(points.map(p => p.y)), crossY: spansZero(points.map(p => p.x)) });
        drawChart("Parábola (Bhaskara)", {
            type: "line",
            data: { datasets },
            options: {
                responsive: true, maintainAspectRatio: false,
                scales: { x: { type: "linear", ...sc.x }, y: sc.y },
                plugins: { legend: baseLegend() }
            }
        });
    }

    // ── gráfico: Progressões (PA/PG) — sequência de termos, ou soma parcial x limite (PG infinita)
    function chartProgression(op, a1, r, q, n) {
        const t = chartTheme();
        if (a1 === null) { hideChart(); return; }
        if (op === "pgInfinite") {
            if (q === null || Math.abs(q) >= 1) { hideChart(); return; }
            const limit = a1 / (1 - q);
            const count = 20;
            let sum = 0;
            const points = [];
            for (let k = 1; k <= count; k++) { sum += a1 * q ** (k - 1); points.push({ x: k, y: sum }); }
            const allY = [...points.map(p => p.y), limit];
            const sc = baseScales({ crossX: spansZero(allY), crossY: spansZero(points.map(p => p.x)) });
            drawChart("PG — Soma parcial x Limite", {
                type: "line",
                data: { datasets: [
                    { label: "Soma parcial", data: points, borderColor: t.accent, backgroundColor: "transparent", borderWidth: 2, pointRadius: 2, tension: 0.15 },
                    { label: "Limite", data: [{ x: 1, y: limit }, { x: count, y: limit }], borderColor: t.accent2, borderDash: [6, 4], borderWidth: 2, pointRadius: 0 }
                ] },
                options: { responsive: true, maintainAspectRatio: false, scales: { x: { type: "linear", ...sc.x }, y: sc.y }, plugins: { legend: baseLegend() } }
            });
            return;
        }
        const isPG = op === "pgTerm" || op === "pgSum";
        const ratio = isPG ? q : r;
        if (ratio === null || n === null || n < 1) { hideChart(); return; }
        const count = Math.min(Math.floor(n), 100);
        const points = [];
        for (let k = 1; k <= count; k++) points.push({ x: k, y: isPG ? a1 * ratio ** (k - 1) : a1 + (k - 1) * ratio });
        const sc2 = baseScales({ crossX: spansZero(points.map(p => p.y)), crossY: spansZero(points.map(p => p.x)) });
        drawChart(isPG ? "Progressão Geométrica" : "Progressão Aritmética", {
            type: "line",
            data: { datasets: [{ label: "Termos", data: points, borderColor: t.accent, backgroundColor: "transparent", borderWidth: 2, pointRadius: count <= 30 ? 3 : 0, tension: 0.1 }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { x: { type: "linear", ...sc2.x }, y: sc2.y }, plugins: { legend: baseLegend() } }
        });
    }

    // ── gráfico: crescimento financeiro (juros simples x compostos)
    function chartFinanceGrowth(op, capital, taxa, tempo) {
        if (!tempo || tempo <= 0) { hideChart(); return; }
        const t = chartTheme();
        const isCompound = op === "JC" || op === "MC";
        const steps = 30;
        const points = [];
        for (let i = 0; i <= steps; i++) {
            const time = (tempo * i) / steps;
            points.push({ x: time, y: isCompound ? capital * (1 + taxa) ** time : capital * (1 + taxa * time) });
        }
        const sc = baseScales({ crossX: spansZero(points.map(p => p.y)), crossY: spansZero(points.map(p => p.x)) });
        drawChart(isCompound ? "Crescimento — Juros Compostos" : "Crescimento — Juros Simples", {
            type: "line",
            data: { datasets: [{ label: "Montante", data: points, borderColor: t.green, backgroundColor: "transparent", borderWidth: 2, pointRadius: 0, tension: 0.1 }] },
            options: {
                responsive: true, maintainAspectRatio: false,
                scales: {
                    x: { type: "linear", ...sc.x, title: { display: true, text: "Tempo", color: t.tick } },
                    y: { ...sc.y, title: { display: true, text: "Montante", color: t.tick } }
                },
                plugins: { legend: baseLegend() }
            }
        });
    }

    // ── gráfico: movimento (física) — posição x tempo (MRU) ou velocidade x tempo (MRUV)
    function chartPhysicsMotion(op, params) {
        const t = chartTheme();
        if (op === "velocity") {
            const { d, time } = params;
            if (d === null || !time) { hideChart(); return; }
            const points = [{ x: 0, y: 0 }, { x: time, y: (d / time) * time }];
            const sc = baseScales({ crossX: spansZero(points.map(p => p.y)), crossY: spansZero(points.map(p => p.x)) });
            drawChart("Posição x Tempo (MRU)", {
                type: "line",
                data: { datasets: [{ label: "Posição (m)", data: points, borderColor: t.accent, backgroundColor: "transparent", borderWidth: 2, pointRadius: 3, tension: 0 }] },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    scales: {
                        x: { type: "linear", ...sc.x, title: { display: true, text: "Tempo (s)", color: t.tick } },
                        y: { ...sc.y, title: { display: true, text: "Posição (m)", color: t.tick } }
                    },
                    plugins: { legend: baseLegend() }
                }
            });
            return;
        }
        if (op === "acceleration") {
            const { vi, vf, time } = params;
            if (vi === null || vf === null || !time) { hideChart(); return; }
            const points = [{ x: 0, y: vi }, { x: time, y: vf }];
            const sc = baseScales({ crossX: spansZero(points.map(p => p.y)), crossY: spansZero(points.map(p => p.x)) });
            drawChart("Velocidade x Tempo (MRUV)", {
                type: "line",
                data: { datasets: [{ label: "Velocidade (m/s)", data: points, borderColor: t.accent2, backgroundColor: "transparent", borderWidth: 2, pointRadius: 3, tension: 0 }] },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    scales: {
                        x: { type: "linear", ...sc.x, title: { display: true, text: "Tempo (s)", color: t.tick } },
                        y: { ...sc.y, title: { display: true, text: "Velocidade (m/s)", color: t.tick } }
                    },
                    plugins: { legend: baseLegend() }
                }
            });
        }
    }

    // ── gráfico: trigonometria — curva da função no período 0°-360°, com o ângulo informado marcado
    function chartTrig(fn, angleDeg) {
        const t = chartTheme();
        const steps = 72;
        const points = [];
        for (let i = 0; i <= steps; i++) {
            const deg = (360 * i) / steps;
            const rad = deg * Math.PI / 180;
            let y;
            if (fn === "sin") y = Math.sin(rad);
            else if (fn === "cos") y = Math.cos(rad);
            else if (fn === "cot") { y = 1 / Math.tan(rad); if (Math.abs(y) > 10) y = null; }
            else { y = Math.tan(rad); if (Math.abs(y) > 10) y = null; }
            points.push({ x: deg, y });
        }
        const angRad = angleDeg * Math.PI / 180;
        const markY = fn === "sin" ? Math.sin(angRad) : fn === "cos" ? Math.cos(angRad) : fn === "cot" ? 1 / Math.tan(angRad) : Math.tan(angRad);
        const label = fn === "sin" ? "sen(x)" : fn === "cos" ? "cos(x)" : fn === "cot" ? "cotg(x)" : "tan(x)";
        const allY = [...points.map(p => p.y), markY];
        const allX = [...points.map(p => p.x), angleDeg];
        const sc = baseScales({ crossX: spansZero(allY), crossY: spansZero(allX) });
        drawChart(`Função ${label}`, {
            type: "line",
            data: { datasets: [
                { label, data: points, borderColor: t.accent, backgroundColor: "transparent", borderWidth: 2, pointRadius: 0, tension: 0.2, spanGaps: false },
                { label: "Ângulo informado", data: [{ x: angleDeg, y: markY }], borderColor: t.accent2, backgroundColor: t.accent2, pointRadius: 5, showLine: false }
            ] },
            options: {
                responsive: true, maintainAspectRatio: false,
                scales: { x: { type: "linear", ...sc.x, title: { display: true, text: "Ângulo (graus)", color: t.tick } }, y: sc.y },
                plugins: { legend: baseLegend() }
            }
        });
    }

    // ── gráfico: estatística — barras dos valores informados com uma linha tracejada na média
    function chartStatistics(nums, mean) {
        const t = chartTheme();
        drawChart("Distribuição dos Valores", {
            type: "bar",
            data: {
                labels: nums.map((_, i) => String(i + 1)),
                datasets: [
                    { type: "bar", label: "Valores", data: nums, backgroundColor: t.accent, borderColor: t.accent, borderWidth: 1 },
                    { type: "line", label: "Média", data: nums.map(() => mean), borderColor: t.accent2, borderDash: [6, 4], borderWidth: 2, pointRadius: 0 }
                ]
            },
            options: { responsive: true, maintainAspectRatio: false, scales: baseScales(), plugins: { legend: baseLegend() } }
        });
    }
    // Objeto de mapeamento que associa as chaves internas aos nomes legíveis de cada categoria
    const labels = {
        sum: "Soma", subtract: "Subtração", multiply: "Multiplicação", divide: "Divisão",
        bhaskara: "Bhaskara", hypotenuse: "Hipotenusa", electrical: "Grandezas elétricas",
        physics: "Física", progression: "Progressões matemáticas", log: "Logaritmo",
        finance: "Cálculos financeiros", geometry: "Geometria", engineering: "Engenharia",
        trigonometry: "Trigonometria", statistics: "Estatística",
        combinatorics: "Combinatória/Probabilidade", matrices: "Matrizes", units: "Conversor de Unidades",
        modular: "Construtor de Fórmulas (Módulos)"
    };

    // Suboperações de trigonometria: razões trigonométricas, leis dos senos/cossenos e conversão de ângulo
    const trigonometryOptions = {
        sin:          { title: "Seno",                          fields: [{name:"angulo",label:"Ângulo (graus)"}] },
        cos:          { title: "Cosseno",                        fields: [{name:"angulo",label:"Ângulo (graus)"}] },
        tan:          { title: "Tangente",                       fields: [{name:"angulo",label:"Ângulo (graus)"}] },
        cot:          { title: "Cotangente",                     fields: [{name:"angulo",label:"Ângulo (graus)"}] },
        lawSines:     { title: "Lei dos Senos (lado desconhecido)", fields: [{name:"ladoA",label:"Lado conhecido (a)"},{name:"anguloA",label:"Ângulo oposto a 'a' (graus)"},{name:"anguloB",label:"Ângulo oposto ao lado desconhecido (graus)"}] },
        lawCosines:   { title: "Lei dos Cossenos (lado desconhecido)", fields: [{name:"ladoB",label:"Lado b"},{name:"ladoC",label:"Lado c"},{name:"anguloA",label:"Ângulo A, entre b e c (graus)"}] },
        convertAngle: { title: "Conversão Graus ↔ Radianos",     fields: [{name:"valor",label:"Valor"},{name:"de",label:"De: 0=graus 1=radianos"}] }
    };

    // Suboperações de estatística descritiva — todas recebem uma lista de valores separados por vírgula
    const statisticsOptions = {
        mean:     { title: "Média",          fields: [{name:"valores",label:"Valores",type:"text"}] },
        median:   { title: "Mediana",        fields: [{name:"valores",label:"Valores",type:"text"}] },
        mode:     { title: "Moda",           fields: [{name:"valores",label:"Valores",type:"text"}] },
        stdDev:   { title: "Desvio Padrão",  fields: [{name:"valores",label:"Valores",type:"text"}] },
        variance: { title: "Variância",      fields: [{name:"valores",label:"Valores",type:"text"}] }
    };

    // Suboperações de combinatória/probabilidade
    const combinatoricsOptions = {
        factorial:   { title: "Fatorial",              fields: [{name:"n",label:"n"}] },
        permutation: { title: "Permutação (Anx)",       fields: [{name:"n",label:"n (total)"},{name:"x",label:"x (escolhidos)"}] },
        combination: { title: "Combinação (Cnx)",       fields: [{name:"n",label:"n (total)"},{name:"x",label:"x (escolhidos)"}] }
    };

    // Suboperações de matrizes — matrizes 2x2 informadas como 4 números separados por vírgula (linha por linha),
    // e a matriz 3x3 do determinante como 9 números
    const matricesOptions = {
        sum2x2:  { title: "Soma de Matrizes 2x2",           fields: [{name:"m1",label:"Matriz A",type:"matrix",size:2},{name:"m2",label:"Matriz B",type:"matrix",size:2}] },
        mult2x2: { title: "Multiplicação de Matrizes 2x2",  fields: [{name:"m1",label:"Matriz A",type:"matrix",size:2},{name:"m2",label:"Matriz B",type:"matrix",size:2}] },
        det2x2:  { title: "Determinante 2x2",               fields: [{name:"m1",label:"Matriz",type:"matrix",size:2}] },
        det3x3:  { title: "Determinante 3x3",               fields: [{name:"m1",label:"Matriz",type:"matrix",size:3}] }
    };

    // Estrutura de dados com todas as suboperações financeiras, os seus títulos e os campos necessários
    const financeOptions = {
        JS:     { title: "Juros Simples",              fields: [{name:"capital",label:"Capital inicial"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        MS:     { title: "Montante Simples",           fields: [{name:"capital",label:"Capital inicial"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        JC:     { title: "Juros Compostos",            fields: [{name:"capital",label:"Capital inicial"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        MC:     { title: "Montante Composto",          fields: [{name:"capital",label:"Capital inicial"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        TJ:     { title: "Taxa de Juros Simples",      fields: [{name:"juros",label:"Juros"},{name:"capital",label:"Capital"},{name:"tempo",label:"Tempo"}] },
        TP:     { title: "Tempo (Juros Simples)",      fields: [{name:"juros",label:"Juros"},{name:"capital",label:"Capital"},{name:"taxa",label:"Taxa (ex: 0.05)"}] },
        DS:     { title: "Desconto Simples",           fields: [{name:"nominal",label:"Valor nominal"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        DC:     { title: "Desconto Composto",          fields: [{name:"nominal",label:"Valor nominal"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        PR:     { title: "Parcela (Tabela PRICE)",     fields: [{name:"valor",label:"Valor financiado"},{name:"taxa",label:"Taxa mensal (ex: 0.02)"},{name:"parcelas",label:"Nº de parcelas"}] },
        SAC:    { title: "Amortização SAC (1ª parcela)", fields: [{name:"valor",label:"Valor financiado"},{name:"taxa",label:"Taxa mensal (ex: 0.02)"},{name:"parcelas",label:"Nº de parcelas"}] },
        VP:     { title: "Valor Presente",             fields: [{name:"futuro",label:"Valor futuro"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        VF:     { title: "Valor Futuro",               fields: [{name:"presente",label:"Valor presente"},{name:"taxa",label:"Taxa (ex: 0.05)"},{name:"tempo",label:"Tempo"}] },
        ROI:    { title: "ROI — Retorno s/ investimento", fields: [{name:"ganho",label:"Ganho obtido"},{name:"custo",label:"Custo do investimento"}] },
        BREAK:  { title: "Ponto de Equilíbrio",        fields: [{name:"fixos",label:"Custos fixos"},{name:"preco",label:"Preço unitário"},{name:"variavel",label:"Custo variável unitário"}] },
        MARGEM: { title: "Margem de Lucro",            fields: [{name:"receita",label:"Receita"},{name:"custo",label:"Custo"}] },
        MARKUP: { title: "Markup",                     fields: [{name:"custo",label:"Custo do produto"},{name:"markup",label:"Markup (%)"}] },
        DEPSL:  { title: "Depreciação Linear",         fields: [{name:"valorInicial",label:"Valor inicial"},{name:"valorResidual",label:"Valor residual"},{name:"vidaUtil",label:"Vida útil (anos)"}] },
        LUCROB: { title: "Lucro Bruto",                fields: [{name:"receita",label:"Receita total"},{name:"cmv",label:"CMV (custo das mercadorias)"}] }
    };

    // Dicionário com fórmulas e subopções de eletricidade e eletrónica, mapeando variáveis e inputs
    const electricalOptions = {
        R: { title: "Resistência", fields: [{name:"corrente",label:"Corrente (A) — 0 se não souber"},{name:"voltagem",label:"Voltagem (V) — 0 se não souber"},{name:"potencia",label:"Potência (W) — 0 se não souber"}] },
        I: { title: "Corrente",    fields: [{name:"potencia",label:"Potência (W) — 0 se não souber"},{name:"voltagem",label:"Voltagem (V) — 0 se não souber"},{name:"resistencia",label:"Resistência (Ω) — 0 se não souber"}] },
        P: { title: "Potência",    fields: [{name:"voltagem",label:"Voltagem (V) — 0 se não souber"},{name:"resistencia",label:"Resistência (Ω) — 0 se não souber"},{name:"corrente",label:"Corrente (A) — 0 se não souber"}] },
        V: { title: "Voltagem",    fields: [{name:"corrente",label:"Corrente (A) — 0 se não souber"},{name:"resistencia",label:"Resistência (Ω) — 0 se não souber"},{name:"potencia",label:"Potência (W) — 0 se não souber"}] },
        RS: { title: "Resistores em Série (Req)", fields: [{name:"valores",label:"Resistores (Ω)",type:"text"}] },
        RP: { title: "Resistores em Paralelo (Req)", fields: [{name:"valores",label:"Resistores (Ω)",type:"text"}] },
        CS: { title: "Capacitores em Série (Ceq)", fields: [{name:"valores",label:"Capacitores (F)",type:"text"}] },
        CP: { title: "Capacitores em Paralelo (Ceq)", fields: [{name:"valores",label:"Capacitores (F)",type:"text"}] },
        LS: { title: "Indutores em Série (Leq)", fields: [{name:"valores",label:"Indutores (H)",type:"text"}] },
        LP: { title: "Indutores em Paralelo (Leq)", fields: [{name:"valores",label:"Indutores (H)",type:"text"}] }
    };

    // Subopções focadas em cinemática e mecânica clássica na área da física
    const physicsOptions = {
        velocity:     { title: "Velocidade média",   fields: [{name:"distancia",label:"Distância (m)"},{name:"tempo",label:"Tempo (s)"}] },
        acceleration: { title: "Aceleração",          fields: [{name:"velocidadeInicial",label:"Vel. inicial (m/s)"},{name:"velocidadeFinal",label:"Vel. final (m/s)"},{name:"tempo",label:"Tempo (s)"}] },
        force:        { title: "Força (F = m·a)",     fields: [{name:"massa",label:"Massa (kg)"},{name:"aceleracao",label:"Aceleração (m/s²)"}] },
        work:         { title: "Trabalho",            fields: [{name:"forca",label:"Força (N)"},{name:"distancia",label:"Distância (m)"}] },
        pressure:     { title: "Pressão",             fields: [{name:"forca",label:"Força (N)"},{name:"area",label:"Área (m²)"}] },
        density:      { title: "Densidade",           fields: [{name:"massa",label:"Massa (kg)"},{name:"volume",label:"Volume (m³)"}] },
        power:        { title: "Potência física",     fields: [{name:"trabalho",label:"Trabalho (J)"},{name:"tempo",label:"Tempo (s)"}] },
        kinetic:      { title: "Energia cinética",    fields: [{name:"massa",label:"Massa (kg)"},{name:"velocidade",label:"Velocidade (m/s)"}] }
    };

    // Mapeamento de cálculos de sequências numéricas (Progressão Aritmética e Geométrica)
    const progressionOptions = {
        paTerm:     { title: "PA — termo geral",   fields: [{name:"a1",label:"Primeiro termo"},{name:"r",label:"Razão"},{name:"n",label:"Número do termo"}] },
        paSum:      { title: "PA — soma",          fields: [{name:"a1",label:"Primeiro termo"},{name:"r",label:"Razão"},{name:"n",label:"Qtd. de termos"}] },
        pgTerm:     { title: "PG — termo geral",   fields: [{name:"a1",label:"Primeiro termo"},{name:"q",label:"Razão"},{name:"n",label:"Número do termo"}] },
        pgSum:      { title: "PG — soma finita",   fields: [{name:"a1",label:"Primeiro termo"},{name:"q",label:"Razão"},{name:"n",label:"Qtd. de termos"}] },
        pgInfinite: { title: "PG — soma infinita", fields: [{name:"a1",label:"Primeiro termo"},{name:"q",label:"Razão (|q| < 1)"}] }
    };

    // Opções detalhadas de geometria plana e espacial contendo os dados necessários para áreas e volumes
    const geometryOptions = {
        circleArea:      { title: "Círculo — Área e Circunferência",       fields: [{name:"raio",label:"Raio"}] },
        squareArea:      { title: "Quadrado — Área, Perímetro e Diagonal", fields: [{name:"lado",label:"Lado"}] },
        rectArea:        { title: "Retângulo — Área, Perímetro e Diagonal",fields: [{name:"base",label:"Base"},{name:"altura",label:"Altura"}] },
        triangleArea:    { title: "Triângulo — Área (base × altura)",      fields: [{name:"base",label:"Base"},{name:"altura",label:"Altura"}] },
        triangleHeron:   { title: "Triângulo — Área (Fórmula de Heron)",   fields: [{name:"ladoA",label:"Lado A"},{name:"ladoB",label:"Lado B"},{name:"ladoC",label:"Lado C"}] },
        trapezoid:       { title: "Trapézio — Área",                       fields: [{name:"baseMaior",label:"Base maior"},{name:"baseMenor",label:"Base menor"},{name:"altura",label:"Altura"}] },
        rhombus:         { title: "Losango — Área e Lado",                 fields: [{name:"d1",label:"Diagonal maior"},{name:"d2",label:"Diagonal menor"}] },
        regularPolygon:  { title: "Polígono Regular — Área e Perímetro",   fields: [{name:"lados",label:"Nº de lados"},{name:"lado",label:"Comprimento do lado"}] },
        ellipseArea:     { title: "Elipse — Área",                         fields: [{name:"semiEixoA",label:"Semi-eixo maior (a)"},{name:"semiEixoB",label:"Semi-eixo menor (b)"}] },
        sectorArea:      { title: "Setor Circular — Área e Arco",          fields: [{name:"raio",label:"Raio"},{name:"angulo",label:"Ângulo central (graus)"}] },
        sphereVol:       { title: "Esfera — Volume e Área",                fields: [{name:"raio",label:"Raio"}] },
        cubeVol:         { title: "Cubo — Volume, Área e Diagonal",        fields: [{name:"aresta",label:"Aresta"}] },
        boxVol:          { title: "Paralelepípedo — Volume e Área",        fields: [{name:"comprimento",label:"Comprimento"},{name:"largura",label:"Largura"},{name:"altura",label:"Altura"}] },
        cylinderVol:     { title: "Cilindro — Volume e Área",              fields: [{name:"raio",label:"Raio da base"},{name:"altura",label:"Altura"}] },
        coneVol:         { title: "Cone — Volume, Geratriz e Área",        fields: [{name:"raio",label:"Raio da base"},{name:"altura",label:"Altura"}] },
        pyramidVol:      { title: "Pirâmide — Volume (base quadrada)",     fields: [{name:"ladoBase",label:"Lado da base"},{name:"altura",label:"Altura"}] },
        torusVol:        { title: "Toro — Volume e Área",                  fields: [{name:"R",label:"Raio maior (R)"},{name:"r",label:"Raio do tubo (r)"}] }
    };

    // Extensa lista de fórmulas científicas e de engenharias (estruturas, fluidos, termodinâmica)
    const engineeringOptions = {
        tensao:           { title: "Tensão Normal σ = F/A",                  fields: [{name:"forca",label:"Força (N)"},{name:"area",label:"Área da seção (m²)"}] },
        deformacao:       { title: "Deformação ε = ΔL/L",                   fields: [{name:"deltaL",label:"Variação de comprimento (m)"},{name:"L",label:"Comprimento original (m)"}] },
        modElastico:      { title: "Módulo de Elasticidade E = σ/ε",        fields: [{name:"tensao",label:"Tensão (Pa)"},{name:"deformacao",label:"Deformação (adimensional)"}] },
        momentoFletor:    { title: "Tensão de Flexão σ = M·c/I",            fields: [{name:"momento",label:"Momento fletor (N·m)"},{name:"c",label:"Distância neutra-borda (m)"},{name:"inercia",label:"Momento de inércia (m⁴)"}] },
        cisalhamento:     { title: "Tensão de Cisalhamento τ = F/A",        fields: [{name:"forca",label:"Força cortante (N)"},{name:"area",label:"Área de corte (m²)"}] },
        torque:           { title: "Tensão de Torção τ = T·r/J",            fields: [{name:"torque",label:"Torque (N·m)"},{name:"raio",label:"Raio (m)"},{name:"J",label:"Momento polar de inércia (m⁴)"}] },
        flambagem:        { title: "Carga Crítica de Euler",                 fields: [{name:"E",label:"Módulo de elasticidade (Pa)"},{name:"I",label:"Momento de inércia (m⁴)"},{name:"Le",label:"Comprimento efetivo (m)"}] },
        calorQ:           { title: "Calor Sensível Q = m·c·ΔT",             fields: [{name:"massa",label:"Massa (kg)"},{name:"calor_esp",label:"Calor específico (J/kg·K)"},{name:"deltaT",label:"ΔT (°C ou K)"}] },
        dilatacao:        { title: "Dilatação Linear ΔL = α·L·ΔT",          fields: [{name:"alfa",label:"Coef. dilatação (1/°C)"},{name:"L",label:"Comprimento inicial (m)"},{name:"deltaT",label:"ΔT (°C)"}] },
        rendimento:       { title: "Rendimento de Máquina (%)",              fields: [{name:"potUtil",label:"Potência útil (W)"},{name:"potTotal",label:"Potência total (W)"}] },
        vazao:            { title: "Vazão Q = A·v",                          fields: [{name:"area",label:"Área da seção (m²)"},{name:"velocidade",label:"Velocidade do fluido (m/s)"}] },
        reynolds:         { title: "Número de Reynolds",                     fields: [{name:"rho",label:"Densidade do fluido (kg/m³)"},{name:"v",label:"Velocidade (m/s)"},{name:"D",label:"Diâmetro hidráulico (m)"},{name:"mu",label:"Viscosidade dinâmica (Pa·s)"}] },
        bernoulli:        { title: "Pressão — Bernoulli simplificado",       fields: [{name:"p1",label:"Pressão 1 (Pa)"},{name:"rho",label:"Densidade (kg/m³)"},{name:"v1",label:"Velocidade 1 (m/s)"},{name:"v2",label:"Velocidade 2 (m/s)"}] },
        pressHidro:       { title: "Pressão Hidrostática ρ·g·h",            fields: [{name:"rho",label:"Densidade (kg/m³)"},{name:"h",label:"Profundidade (m)"}] },
        capacitor:        { title: "Energia no Capacitor ½·C·V²",           fields: [{name:"C",label:"Capacitância (F)"},{name:"V",label:"Tensão (V)"}] },
        indutor:          { title: "Energia no Indutor ½·L·I²",             fields: [{name:"L_ind",label:"Indutância (H)"},{name:"I",label:"Corrente (A)"}] },
        reatorLC:         { title: "Frequência de Ressonância LC",           fields: [{name:"L_ind",label:"Indutância (H)"},{name:"C",label:"Capacitância (F)"}] },
        divisorTensao:    { title: "Divisor de Tensão",                      fields: [{name:"Vin",label:"Tensão de entrada (V)"},{name:"R1",label:"Resistor R1 (Ω)"},{name:"R2",label:"Resistor R2 (Ω)"}] },
        cargaDistribuida: { title: "Reações — Viga Biapoiada Carga Uniforme",fields: [{name:"w",label:"Carga distribuída (N/m)"},{name:"L",label:"Comprimento da viga (m)"}] },
        momentoMax:       { title: "Momento Máximo — Viga Biapoiada",       fields: [{name:"w",label:"Carga distribuída (N/m)"},{name:"L",label:"Comprimento da viga (m)"}] },
        inerciRetangulo:  { title: "Momento de Inércia — Seção Retangular", fields: [{name:"base",label:"Base (m)"},{name:"altura",label:"Altura (m)"}] },
        inerciCirculo:    { title: "Momento de Inércia — Seção Circular",   fields: [{name:"raio",label:"Raio (m)"}] },
        convTemp:         { title: "Conversão de Temperatura",               fields: [{name:"valor",label:"Valor"},{name:"de",label:"De: 0=°C  1=°F  2=K"}] },
        convPressao:      { title: "Conversão de Pressure (entrada em Pa)",   fields: [{name:"valor",label:"Valor (Pa)"}] }
    };

    // Dados de conversão de unidades: tabelas de fator (base: metro / grama) + escolhas dos dropdowns
    // ── explicações teóricas curtas, mostradas antes do passo a passo ────────
    const theoryText = {
        topLevel: {
            sum: "A soma é a operação básica de reunir várias quantidades em uma só, feita adicionando os números um a um, na ordem em que aparecem.",
            subtract: "A subtração calcula a diferença entre quantidades, indo da primeira em direção às seguintes, uma de cada vez.",
            multiply: "A multiplicação é uma forma resumida de somar um número repetidamente; aqui é feita entre dois valores.",
            divide: "A divisão reparte uma quantidade em partes iguais, indicando quantas vezes o divisor 'cabe' dentro do dividendo.",
            bhaskara: "A fórmula de Bhaskara resolve equações do 2º grau (ax² + bx + c = 0). Primeiro calcula-se o discriminante Δ, que diz quantas raízes reais existem; depois as raízes vêm de (−b ± √Δ) / 2a.",
            hypotenuse: "O Teorema de Pitágoras relaciona os lados de um triângulo retângulo: o quadrado da hipotenusa é igual à soma dos quadrados dos catetos.",
            log: "O logaritmo de x na base b responde à pergunta 'a que expoente eu elevo b para chegar em x?'. A troca de base permite calcular qualquer logaritmo usando ln (logaritmo natural).",
            modular: "Aqui você monta sua própria expressão combinando funções trigonométricas, operadores e valores na ordem que quiser — como montar uma fórmula personalizada bloco por bloco. O cálculo é resolvido respeitando a ordem das operações: primeiro funções e parênteses, depois potência, depois multiplicação/divisão, e por último soma/subtração."
        },
        finance: {
            JS: "Juros simples: os juros incidem sempre sobre o capital inicial, sem 'juros sobre juros'. Cresce de forma linear ao longo do tempo.",
            MS: "Montante simples é o capital inicial somado aos juros simples acumulados até o momento t.",
            JC: "Juros compostos: a cada período, os juros passam a incidir também sobre os juros anteriores ('juros sobre juros'), gerando crescimento exponencial.",
            MC: "Montante composto é o valor final do capital após t períodos de juros compostos a uma taxa i.",
            TJ: "Isolando a taxa na fórmula de juros simples, dá pra descobrir qual taxa foi aplicada a partir do capital, tempo e juros obtidos.",
            TP: "Isolando o tempo na fórmula de juros simples, dá pra descobrir em quanto tempo certo juros foi gerado.",
            DS: "Desconto simples é o abatimento aplicado a um valor nominal futuro para trazê-lo ao valor presente, de forma linear (proporcional ao tempo).",
            DC: "Desconto composto traz um valor nominal futuro ao valor presente descontando os juros compostos período a período.",
            PR: "Tabela PRICE: todas as parcelas do financiamento têm o mesmo valor, combinando amortização crescente e juros decrescentes.",
            SAC: "Sistema de Amortização Constante: a amortização é sempre a mesma a cada parcela, e os juros (calculados sobre o saldo devedor) vão diminuindo — por isso a primeira parcela é a maior.",
            VP: "Valor presente é quanto um valor futuro vale hoje, descontando os juros compostos do período entre hoje e o vencimento.",
            VF: "Valor futuro é quanto um valor de hoje vai valer depois de render juros compostos por um período.",
            ROI: "Retorno sobre investimento (ROI) mede, em porcentagem, o quanto se ganhou (ou perdeu) em relação ao que foi investido.",
            BREAK: "Ponto de equilíbrio é a quantidade de unidades vendidas necessária para que a receita cubra exatamente os custos fixos e variáveis, sem lucro nem prejuízo.",
            MARGEM: "Margem de lucro é a porcentagem da receita que sobra como lucro depois de descontar os custos.",
            MARKUP: "Markup é o percentual aplicado sobre o custo de um produto para chegar ao preço de venda, cobrindo custos e margem de lucro desejada.",
            DEPSL: "Depreciação linear reparte a perda de valor de um bem igualmente ao longo da sua vida útil, do valor inicial até o valor residual.",
            LUCROB: "Lucro bruto é a receita menos o custo das mercadorias vendidas (CMV), antes de descontar despesas operacionais, impostos etc."
        },
        electrical: {
            R: "A Lei de Ohm (V = R×I) relaciona tensão, resistência e corrente num circuito; aqui isolamos a resistência a partir das outras duas grandezas informadas.",
            I: "A partir da Lei de Ohm e da fórmula de potência (P = V×I), a corrente pode ser calculada de diferentes formas dependendo de quais grandezas você conhece.",
            P: "Potência elétrica é a taxa de energia consumida ou fornecida por um circuito; pode ser calculada combinando tensão, corrente e resistência.",
            V: "A tensão (diferença de potencial) pode ser obtida a partir da corrente e resistência (Lei de Ohm) ou da potência, dependendo do que for conhecido.",
            RS: "Em uma associação de resistores em série, a mesma corrente passa por todos eles, e a resistência equivalente é simplesmente a soma de cada resistência.",
            RP: "Em uma associação de resistores em paralelo, a tensão é a mesma em todos, e o inverso da resistência equivalente é a soma dos inversos de cada resistência.",
            CS: "Capacitores em série se comportam de forma 'inversa' aos resistores: o inverso da capacitância equivalente é a soma dos inversos de cada capacitor.",
            CP: "Capacitores em paralelo somam suas capacitâncias diretamente, pois cada um armazena carga na mesma tensão.",
            LS: "Indutores em série (sem acoplamento magnético) somam suas indutâncias diretamente, como resistores em série.",
            LP: "Indutores em paralelo (sem acoplamento) combinam-se pelo inverso da soma dos inversos, como resistores em paralelo."
        },
        physics: {
            velocity: "Velocidade média é a razão entre o deslocamento percorrido e o tempo gasto para percorrê-lo (Movimento Retilíneo Uniforme).",
            acceleration: "Aceleração é a taxa de variação da velocidade ao longo do tempo — o quanto a velocidade muda por segundo.",
            force: "A Segunda Lei de Newton (F = m×a) diz que a força resultante sobre um corpo é proporcional à sua massa e à aceleração que ela produz.",
            work: "Trabalho mecânico é a energia transferida por uma força ao deslocar um corpo, na direção do deslocamento.",
            pressure: "Pressão é a força aplicada distribuída sobre uma área — quanto menor a área, maior a pressão para a mesma força.",
            density: "Densidade relaciona a massa de um material com o volume que ele ocupa, indicando o quão 'compacta' é a matéria.",
            power: "Potência mede a rapidez com que um trabalho é realizado — quanta energia é transferida por unidade de tempo.",
            kinetic: "Energia cinética é a energia associada ao movimento de um corpo, que cresce com o quadrado da velocidade."
        },
        progression: {
            paTerm: "Numa Progressão Aritmética (PA), cada termo é obtido somando uma razão constante r ao termo anterior; o termo geral calcula qualquer posição direto, sem somar um por um.",
            paSum: "A soma dos termos de uma PA pode ser calculada multiplicando a média entre o primeiro e o último termo pela quantidade de termos.",
            pgTerm: "Numa Progressão Geométrica (PG), cada termo é obtido multiplicando o anterior por uma razão constante q; o termo geral calcula qualquer posição direto.",
            pgSum: "A soma dos n primeiros termos de uma PG finita usa uma fórmula fechada baseada na razão q, evitando somar termo por termo.",
            pgInfinite: "Quando |q| < 1, os termos de uma PG ficam cada vez menores e a soma infinita converge para um valor finito."
        },
        geometry: {
            circleArea: "A área do círculo cresce com o quadrado do raio (π×r²); a circunferência é o seu perímetro, proporcional ao raio (2×π×r).",
            squareArea: "Um quadrado tem todos os lados iguais; sua área é o lado ao quadrado e a diagonal se relaciona ao lado por √2 (Pitágoras).",
            rectArea: "Num retângulo, área é base vezes altura; a diagonal é obtida pelo Teorema de Pitágoras entre base e altura.",
            triangleArea: "A área de um triângulo é metade do produto entre a base e a altura relativa a essa base.",
            triangleHeron: "A fórmula de Heron calcula a área de um triângulo só a partir dos 3 lados, sem precisar conhecer a altura, usando o semiperímetro p.",
            trapezoid: "A área do trapézio é a média das duas bases (maior e menor) multiplicada pela altura entre elas.",
            rhombus: "No losango, a área é metade do produto das diagonais; o lado pode ser obtido pelas metades das diagonais formando um triângulo retângulo.",
            regularPolygon: "Um polígono regular pode ser dividido em triângulos a partir do centro; o apótema (distância do centro a um lado) permite calcular a área total.",
            ellipseArea: "A área da elipse generaliza a do círculo, usando os dois semieixos (maior e menor) no lugar do raio único.",
            sectorArea: "Um setor circular é uma 'fatia' do círculo; sua área e comprimento de arco são proporcionais ao ângulo central (em radianos).",
            sphereVol: "O volume da esfera cresce com o cubo do raio; sua área de superfície cresce com o quadrado do raio.",
            cubeVol: "Num cubo, todas as arestas são iguais; volume é aresta ao cubo, e a diagonal interna envolve √3 (Pitágoras em 3D).",
            boxVol: "O volume de um paralelepípedo (caixa retangular) é o produto das três dimensões; a área total soma as 3 faces distintas, dobradas.",
            cylinderVol: "O volume do cilindro é a área da base circular multiplicada pela altura; a área total soma as duas bases e a lateral.",
            coneVol: "O volume do cone é um terço do volume de um cilindro de mesma base e altura; a geratriz é a distância do ápice até a borda da base.",
            pyramidVol: "O volume de uma pirâmide é um terço da área da base multiplicada pela altura.",
            torusVol: "Um toro (formato de rosquinha) tem seu volume e área calculados a partir do raio maior (R, do centro do tubo) e do raio menor (r, do tubo)."
        },
        engineering: {
            tensao: "Tensão normal (σ) é a força aplicada distribuída pela área da seção transversal de um material, medindo o quanto ele está sendo 'esticado' ou 'comprimido'.",
            deformacao: "Deformação específica (ε) é a variação relativa do comprimento de um material sob carga, comparada ao comprimento original.",
            modElastico: "O módulo de elasticidade (Módulo de Young) relaciona tensão e deformação, indicando a rigidez de um material dentro do regime elástico (Lei de Hooke).",
            momentoFletor: "A tensão de flexão num ponto de uma viga depende do momento fletor aplicado, da distância até a linha neutra e do momento de inércia da seção.",
            cisalhamento: "Tensão de cisalhamento é a força aplicada paralelamente a uma superfície, dividida pela área dessa superfície.",
            torque: "A tensão de cisalhamento por torção depende do torque aplicado, da distância ao eixo e do momento polar de inércia da seção.",
            flambagem: "A carga crítica de flambagem (fórmula de Euler) é a carga axial máxima que uma coluna esbelta suporta antes de flambar (dobrar lateralmente).",
            calorQ: "Calor sensível é a energia necessária para variar a temperatura de uma substância, proporcional à massa, ao calor específico e à variação de temperatura.",
            dilatacao: "Dilatação térmica linear é o quanto um material se expande (ou contrai) ao variar de temperatura, proporcional ao seu comprimento original e ao coeficiente de dilatação.",
            rendimento: "Rendimento é a razão entre a potência (ou energia) útil aproveitada e a potência total fornecida a um sistema, em porcentagem.",
            vazao: "Vazão volumétrica é o volume de fluido que passa por uma seção transversal por unidade de tempo, proporcional à área e à velocidade do fluido.",
            reynolds: "O número de Reynolds indica se um escoamento é laminar ou turbulento, comparando forças inerciais e viscosas do fluido.",
            bernoulli: "A equação de Bernoulli (simplificada, sem variação de altura) relaciona pressão e velocidade num fluido: onde o fluido acelera, a pressão cai.",
            pressHidro: "Pressão hidrostática é a pressão exercida por uma coluna de fluido parado, proporcional à densidade do fluido, à gravidade e à profundidade.",
            capacitor: "A energia armazenada num capacitor carregado depende da sua capacitância e do quadrado da tensão aplicada.",
            indutor: "A energia armazenada no campo magnético de um indutor depende da sua indutância e do quadrado da corrente que passa por ele.",
            reatorLC: "Um circuito LC (indutor + capacitor) oscila numa frequência de ressonância natural, determinada pelos valores de L e C.",
            divisorTensao: "Um divisor de tensão resistivo reparte a tensão de entrada entre dois resistores em série, proporcionalmente ao valor de cada um.",
            cargaDistribuida: "Uma carga distribuída uniformemente sobre uma viga biapoiada gera reações iguais em cada apoio, metade do total da carga.",
            momentoMax: "Numa viga biapoiada com carga distribuída, o momento fletor máximo ocorre no meio do vão.",
            inerciRetangulo: "O momento de inércia de uma seção retangular mede sua resistência à flexão em torno do eixo que passa pelo centro, na direção da base.",
            inerciCirculo: "O momento de inércia de uma seção circular mede sua resistência à flexão/torção, crescendo com a quarta potência do raio.",
            convTemp: "As escalas Celsius, Fahrenheit e Kelvin medem temperatura com pontos de referência diferentes; as fórmulas de conversão ajustam escala e deslocamento entre elas.",
            convPressao: "Pressão pode ser expressa em várias unidades (Pa, kPa, bar, atm, psi); a conversão usa o fator fixo entre cada unidade e o Pascal (unidade do SI)."
        },
        trigonometry: {
            sin: "O seno de um ângulo, num triângulo retângulo, é a razão entre o cateto oposto e a hipotenusa; no círculo trigonométrico, é a coordenada vertical.",
            cos: "O cosseno de um ângulo, num triângulo retângulo, é a razão entre o cateto adjacente e a hipotenusa; no círculo trigonométrico, é a coordenada horizontal.",
            tan: "A tangente é a razão entre seno e cosseno (cateto oposto sobre cateto adjacente); é indefinida onde o cosseno vale zero.",
            cot: "A cotangente é o inverso da tangente (cosseno sobre seno); é indefinida onde o seno vale zero.",
            lawSines: "A Lei dos Senos relaciona os lados de um triângulo qualquer com o seno dos ângulos opostos a eles, sendo essa razão constante para o triângulo todo.",
            lawCosines: "A Lei dos Cossenos generaliza o Teorema de Pitágoras para qualquer triângulo, incluindo um termo que depende do cosseno do ângulo entre dois lados.",
            convertAngle: "Graus e radianos são duas formas de medir ângulos; uma volta completa equivale a 360° ou 2π radianos, o que dá o fator de conversão π/180."
        },
        statistics: {
            mean: "A média aritmética resume um conjunto de valores somando todos e dividindo pela quantidade de valores.",
            median: "A mediana é o valor que fica exatamente no meio de um conjunto de dados ordenado, dividindo-o em duas metades iguais.",
            mode: "A moda é o valor (ou valores) que mais se repete em um conjunto de dados.",
            stdDev: "O desvio padrão mede o quanto os valores costumam se afastar da média, em média — quanto maior, mais espalhados são os dados.",
            variance: "A variância mede a dispersão dos dados em relação à média, elevando ao quadrado cada distância à média (o desvio padrão é sua raiz quadrada)."
        },
        combinatorics: {
            factorial: "O fatorial de n (n!) é o produto de todos os inteiros positivos de 1 até n, usado para contar quantas ordens diferentes existem para organizar n itens.",
            permutation: "Arranjo simples conta quantas formas existem de escolher e ordenar x itens dentre n disponíveis, onde a ordem importa.",
            combination: "Combinação simples conta quantas formas existem de escolher x itens dentre n disponíveis, onde a ordem NÃO importa."
        },
        matrices: {
            sum2x2: "A soma de duas matrizes é feita somando cada elemento com o elemento correspondente (mesma linha e coluna) da outra matriz.",
            mult2x2: "Na multiplicação de matrizes, cada elemento do resultado é a soma dos produtos entre uma linha da primeira matriz e uma coluna da segunda.",
            det2x2: "O determinante de uma matriz 2×2 mede, entre outras coisas, se o sistema associado tem solução única; é calculado como o produto da diagonal principal menos o da diagonal secundária.",
            det3x3: "O determinante de uma matriz 3×3 pode ser calculado expandindo por cofatores (ou regra de Sarrus), combinando os determinantes 2×2 das submatrizes."
        },
        units: {
            length: "Unidades de comprimento se relacionam por fatores fixos de potência de 10 (no sistema métrico) ou por fatores históricos (no sistema imperial); a conversão passa por uma unidade base comum (o metro).",
            mass: "Unidades de massa se relacionam por fatores fixos; a conversão passa por uma unidade base comum (o grama) antes de chegar na unidade de destino.",
            temperature: "Celsius, Fahrenheit e Kelvin têm zeros e 'tamanhos de grau' diferentes; a conversão entre elas passa por fórmulas específicas, não só um fator multiplicativo.",
            angle: "Graus e radianos medem o mesmo ângulo de formas diferentes; uma volta completa (360°) equivale a 2π radianos."
        }
    };

    // Busca a explicação teórica de uma operação; cai para o nível topLevel quando não há subtipo
    function theoryFor(type, op) {
        if (op && theoryText[type] && theoryText[type][op]) return theoryText[type][op];
        if (theoryText.topLevel[type]) return theoryText.topLevel[type];
        return "";
    }


    const lengthUnits = { mm: 0.001, cm: 0.01, m: 1, km: 1000, pol: 0.0254, pe: 0.3048, milha: 1609.34 };
    const lengthChoices = [
        { value: "mm",    label: "Milímetro (mm)" },
        { value: "cm",    label: "Centímetro (cm)" },
        { value: "m",     label: "Metro (m)" },
        { value: "km",    label: "Quilômetro (km)" },
        { value: "pol",   label: "Polegada (in)" },
        { value: "pe",    label: "Pé (ft)" },
        { value: "milha", label: "Milha (mi)" }
    ];
    const massUnits = { mg: 0.001, g: 1, kg: 1000, ton: 1000000, lb: 453.592, oz: 28.3495 };
    const massChoices = [
        { value: "mg",  label: "Miligrama (mg)" },
        { value: "g",   label: "Grama (g)" },
        { value: "kg",  label: "Quilograma (kg)" },
        { value: "ton", label: "Tonelada (t)" },
        { value: "lb",  label: "Libra (lb)" },
        { value: "oz",  label: "Onça (oz)" }
    ];
    const tempChoices = [
        { value: "C", label: "Celsius (°C)" },
        { value: "F", label: "Fahrenheit (°F)" },
        { value: "K", label: "Kelvin (K)" }
    ];
    const angleUnitChoices = [
        { value: "deg", label: "Graus (°)" },
        { value: "rad", label: "Radianos (rad)" }
    ];

    // Suboperações do conversor de unidades
    const unitsOptions = {
        length:      { title: "Comprimento",  fields: [{name:"valor",label:"Valor"},{name:"de",label:"De",type:"select",choices:lengthChoices},{name:"para",label:"Para",type:"select",choices:lengthChoices}] },
        mass:        { title: "Massa",        fields: [{name:"valor",label:"Valor"},{name:"de",label:"De",type:"select",choices:massChoices},{name:"para",label:"Para",type:"select",choices:massChoices}] },
        temperature: { title: "Temperatura",  fields: [{name:"valor",label:"Valor"},{name:"de",label:"De",type:"select",choices:tempChoices},{name:"para",label:"Para",type:"select",choices:tempChoices}] },
        angle:       { title: "Ângulo (Graus ↔ Radianos)", fields: [{name:"valor",label:"Valor"},{name:"de",label:"De",type:"select",choices:angleUnitChoices},{name:"para",label:"Para",type:"select",choices:angleUnitChoices}] }
    };

    // ── funções auxiliares (helpers) ──────────────────────────────────────────

    // Gera um <select> de opções pra um campo de fórmula (ex: escolher a unidade "de"/"para")
    function selectFieldInput(name, label, choices) {
        return `<label class="field"><span>${label}</span><select name="${name}">${choices.map(c=>`<option value="${c.value}">${c.label}</option>`).join("")}</select></label>`;
    }

    // Gera o código HTML para um campo de entrada do tipo numérico com rótulo
    function numberInput(name, label, placeholder = "") {
        return `<label class="field"><span>${label}</span><input name="${name}" type="number" step="any" placeholder="${placeholder}"></label>`;
    }

    // Gera o código HTML para um campo de entrada de texto comum com rótulo
    function textInput(name, label, placeholder = "") {
        return `<label class="field"><span>${label}</span><input name="${name}" type="text" placeholder="${placeholder}"></label>`;
    }

    // Gera uma grade de quadradinhos (inputs numéricos) representando uma matriz size x size.
    // Cada célula vira um campo próprio, nomeado "<name>_0", "<name>_1", etc, em ordem de leitura (linha por linha).
    function matrixInput(name, label, size) {
        const cells = [];
        for (let i = 0; i < size * size; i++) {
            cells.push(`<input name="${name}_${i}" type="number" step="any" class="matrix-cell" aria-label="${label} — célula ${i + 1}">`);
        }
        return `<div class="field matrix-field"><span>${label}</span><div class="matrix-grid" style="grid-template-columns: repeat(${size}, 1fr);">${cells.join("")}</div></div>`;
    }

    // Gera o código HTML para uma caixa de seleção (dropdown select) com base num array de opções
    function selectInput(name, label, options, selectedValue) {
        return `<label class="field"><span>${label}</span><select name="${name}">${options.map(o=>`<option value="${o.value}"${o.value===selectedValue?" selected":""}>${o.label}</option>`).join("")}</select></label>`;
    }

    // Injeta o HTML gerado dentro do contentor de campos dinâmicos da página e anexa uma dica, se existir
    function renderFieldSet(html, hint = "") {
        dynamicFields.innerHTML = `<div class="field-grid">${html}</div>${hint?`<p class="hint">${hint}</p>`:""}`;
    }

    // Constrói um menu dropdown secundário focado nas subcategorias de uma operação
    function buildSubSelect(name, label, options, selectedValue) {
        return selectInput(name, label, Object.entries(options).map(([v,c])=>({value:v,label:c.title})), selectedValue);
    }

    // ── renderização de campos dinâmicos ──────────────────────────────────────

    function renderFields() {
        resultBox.textContent = "";
        hideChart();
        hideSteps();
        const type = calcType.value;
        subtitle.textContent = labels[type] || "Calculadora";

        const subMap = {
            finance:       ["financeType",       financeOptions,       "Use ponto decimal, ex: 0.05 para 5%."],
            electrical:    ["electricalType",    electricalOptions,    "Para Leis de Ohm: coloque 0 no campo a calcular. Para associações: informe valores separados por vírgula."],
            physics:       ["physicsType",       physicsOptions,       "Preencha todos os campos com as unidades indicadas."],
            progression:   ["progressionType",   progressionOptions,   "PA e PG usam fórmulas de termo e soma."],
            geometry:      ["geometryType",      geometryOptions,      "Áreas em unidades², volumes em unidades³."],
            engineering:   ["engineeringType",   engineeringOptions,   "Use o SI — Pa, N, m, kg, s."],
            trigonometry:  ["trigonometryType",  trigonometryOptions,  "Ângulos em graus."],
            statistics:    ["statisticsType",    statisticsOptions,    "Informe os valores separados por vírgula, ex: 4, 8, 15, 16, 23."],
            combinatorics: ["combinatoricsType", combinatoricsOptions, "n e x devem ser inteiros não negativos, com x ≤ n."],
            matrices:      ["matricesType",      matricesOptions,      "Preencha cada quadradinho da matriz com o valor correspondente."],
            units:         ["unitsType",         unitsOptions,         "Escolha a unidade de origem e a de destino."]
        };

        if (subMap[type]) {
            const [selName, opts, hint] = subMap[type];
            const selVal = form.elements[selName]?.value || Object.keys(opts)[0];
            const config = opts[selVal];
            const fieldHtml = config.fields.map(f => {
                if (f.type === "text") return textInput(f.name, f.label, "Ex: 10, 20, 30");
                if (f.type === "matrix") return matrixInput(f.name, f.label, f.size);
                if (f.type === "select") return selectFieldInput(f.name, f.label, f.choices);
                return numberInput(f.name, f.label);
            });
            renderFieldSet([buildSubSelect(selName, labels[type], opts, selVal), ...fieldHtml].join(""), hint);
            return;
        }

        if (type === "modular") { renderModularBuilder(); return; }
        if (type === "log") { renderFieldSet([textInput("base","Base do logaritmo","10, 2 ou e"), numberInput("logaritmando","Logaritmando")].join(""), "Para logaritmo natural, use a base e."); return; }
        if (type === "bhaskara") { renderFieldSet([numberInput("a","Coeficiente A"),numberInput("b","Coeficiente B"),numberInput("c","Coeficiente C")].join(""), "Retorna as duas raízes quando existem."); return; }
        if (type === "hypotenuse") { renderFieldSet([numberInput("cateto1","Primeiro cateto"),numberInput("cateto2","Segundo cateto")].join(""), "Calculado por Pitágoras."); return; }
        if (type === "sum" || type === "subtract") { renderFieldSet([textInput("numbers","Números","Ex: 1, 2, 3, 4")].join(""), type==="sum"?"Separe por vírgula, espaço ou quebra de linha.":"Subtração em sequência."); return; }
        renderFieldSet([numberInput("value1","Primeiro número"),numberInput("value2","Segundo número")].join(""), type==="divide"?"primeiro ÷ segundo":"");
    }

    // ── utilitários internos de processamento ──────────────────────────────────

    function parseNumbers(raw) { return raw.split(/[\s,;]+/).map(Number).filter(v=>!Number.isNaN(v)); }
    function getFormValue(name) { return form.elements[name]?.value ?? ""; }
    function rn(name) { const v=Number(getFormValue(name)); return Number.isNaN(v)?null:v; }
    function fmt(v) { return Number(v).toLocaleString("pt-BR",{maximumFractionDigits:10}); }

    // ── submotores de cálculo por categoria ──────────────────────────────────

    function calculateFinance(op) {
        const cfg = financeOptions[op];
        const vals = Object.fromEntries(cfg.fields.map(f=>[f.name,rn(f.name)]));
        if (Object.values(vals).some(v=>v===null)) return "Preencha todos os campos.";
        const {capital,taxa,tempo,juros,nominal,valor,futuro,presente,parcelas,
               ganho,custo,fixos,preco,variavel,markup,receita,cmv,
               valorInicial,valorResidual,vidaUtil} = vals;
        if (["JS","MS","JC","MC"].includes(op)) chartFinanceGrowth(op, capital, taxa, tempo);
        switch(op) {
            case "JS": {
                st(`Fórmula: J = C × i × t`);
                st(`Substituindo: J = ${fmt(capital)} × ${fmt(taxa)} × ${fmt(tempo)}`);
                return `Juros: ${fmt(capital*taxa*tempo)}`;
            }
            case "MS": {
                st(`Fórmula: M = C × (1 + i × t)`);
                st(`Substituindo: M = ${fmt(capital)} × (1 + ${fmt(taxa)} × ${fmt(tempo)}) = ${fmt(capital)} × ${fmt(1+taxa*tempo)}`);
                return `Montante: ${fmt(capital*(1+taxa*tempo))}`;
            }
            case "JC": {
                st(`Fórmula: M = C × (1 + i)^t ; J = M − C`);
                const m=capital*(1+taxa)**tempo;
                st(`Substituindo: M = ${fmt(capital)} × (1 + ${fmt(taxa)})^${fmt(tempo)} = ${fmt(m)}`);
                st(`J = ${fmt(m)} − ${fmt(capital)}`);
                return `Juros compostos: ${fmt(m-capital)}`;
            }
            case "MC": {
                st(`Fórmula: M = C × (1 + i)^t`);
                st(`Substituindo: M = ${fmt(capital)} × (1 + ${fmt(taxa)})^${fmt(tempo)}`);
                return `Montante composto: ${fmt(capital*(1+taxa)**tempo)}`;
            }
            case "TJ": {
                if(!capital||!tempo) return "Capital e tempo ≠ 0.";
                st(`Fórmula: i = J / (C × t)`);
                st(`Substituindo: i = ${fmt(juros)} / (${fmt(capital)} × ${fmt(tempo)})`);
                return `Taxa: ${fmt(juros/(capital*tempo))}`;
            }
            case "TP": {
                if(!capital||!taxa) return "Capital e taxa ≠ 0.";
                st(`Fórmula: t = J / (C × i)`);
                st(`Substituindo: t = ${fmt(juros)} / (${fmt(capital)} × ${fmt(taxa)})`);
                return `Tempo: ${fmt(juros/(capital*taxa))}`;
            }
            case "DS": {
                st(`Fórmula: D = N × i × t ; Valor atual = N − D`);
                const d = nominal*taxa*tempo;
                st(`Substituindo: D = ${fmt(nominal)} × ${fmt(taxa)} × ${fmt(tempo)} = ${fmt(d)}`);
                st(`Valor atual = ${fmt(nominal)} − ${fmt(d)}`);
                return `Desconto: ${fmt(d)}\nValor atual: ${fmt(nominal-d)}`;
            }
            case "DC": {
                st(`Fórmula: VA = N / (1 + i)^t ; D = N − VA`);
                const va=nominal/(1+taxa)**tempo;
                st(`Substituindo: VA = ${fmt(nominal)} / (1 + ${fmt(taxa)})^${fmt(tempo)} = ${fmt(va)}`);
                st(`D = ${fmt(nominal)} − ${fmt(va)}`);
                return `Desconto composto: ${fmt(nominal-va)}\nValor atual: ${fmt(va)}`;
            }
            case "PR": {
                if(!taxa) return "Taxa ≠ 0.";
                st(`Fórmula: PMT = (V × i) / (1 − (1 + i)^(−n))`);
                const p = (valor*taxa)/(1-(1+taxa)**(-parcelas));
                st(`Substituindo: PMT = (${fmt(valor)} × ${fmt(taxa)}) / (1 − (1 + ${fmt(taxa)})^(−${fmt(parcelas)}))`);
                return `Parcela PRICE: ${fmt(p)}`;
            }
            case "SAC": {
                if(!parcelas) return "Parcelas ≠ 0.";
                st(`Fórmula: amortização = V / n ; juros (1ª) = V × i`);
                const a=valor/parcelas,j=valor*taxa;
                st(`Substituindo: amortização = ${fmt(valor)} / ${fmt(parcelas)} = ${fmt(a)}`);
                st(`juros = ${fmt(valor)} × ${fmt(taxa)} = ${fmt(j)}`);
                return `Amortização: ${fmt(a)}\nJuros (1ª parcela): ${fmt(j)}\n1ª parcela total: ${fmt(a+j)}`;
            }
            case "VP": {
                st(`Fórmula: VP = VF / (1 + i)^t`);
                st(`Substituindo: VP = ${fmt(futuro)} / (1 + ${fmt(taxa)})^${fmt(tempo)}`);
                return `Valor presente: ${fmt(futuro/(1+taxa)**tempo)}`;
            }
            case "VF": {
                st(`Fórmula: VF = VP × (1 + i)^t`);
                st(`Substituindo: VF = ${fmt(presente)} × (1 + ${fmt(taxa)})^${fmt(tempo)}`);
                return `Valor futuro: ${fmt(presente*(1+taxa)**tempo)}`;
            }
            case "ROI": {
                if(!custo) return "Custo ≠ 0.";
                st(`Fórmula: ROI = ((Ganho − Custo) / Custo) × 100`);
                st(`Substituindo: ROI = ((${fmt(ganho)} − ${fmt(custo)}) / ${fmt(custo)}) × 100`);
                return `ROI: ${fmt(((ganho-custo)/custo)*100)} %`;
            }
            case "BREAK": {
                if(preco===variavel) return "Preço e custo variável devem ser diferentes.";
                st(`Fórmula: PE = Custos fixos / (Preço − Custo variável)`);
                st(`Substituindo: PE = ${fmt(fixos)} / (${fmt(preco)} − ${fmt(variavel)})`);
                return `Ponto de equilíbrio: ${fmt(fixos/(preco-variavel))} unidades`;
            }
            case "MARGEM": {
                if(!receita) return "Receita ≠ 0.";
                st(`Fórmula: margem = ((Receita − Custo) / Receita) × 100 ; lucro = Receita − Custo`);
                st(`Substituindo: margem = ((${fmt(receita)} − ${fmt(custo)}) / ${fmt(receita)}) × 100`);
                return `Margem: ${fmt(((receita-custo)/receita)*100)} %\nLucro: ${fmt(receita-custo)}`;
            }
            case "MARKUP": {
                st(`Fórmula: preço de venda = Custo × (1 + markup / 100)`);
                st(`Substituindo: preço = ${fmt(custo)} × (1 + ${fmt(markup)} / 100)`);
                return `Preço de venda: ${fmt(custo*(1+markup/100))}`;
            }
            case "DEPSL": {
                if(!vidaUtil) return "Vida útil ≠ 0.";
                st(`Fórmula: depreciação anual = (Valor inicial − Valor residual) / Vida útil`);
                const dep = (valorInicial-valorResidual)/vidaUtil;
                st(`Substituindo: depreciação = (${fmt(valorInicial)} − ${fmt(valorResidual)}) / ${fmt(vidaUtil)} = ${fmt(dep)}`);
                return `Depreciação anual: ${fmt(dep)}\nTaxa: ${fmt((dep/valorInicial)*100)} %`;
            }
            case "LUCROB": {
                if(!receita) return "Receita ≠ 0.";
                st(`Fórmula: lucro bruto = Receita − CMV ; margem bruta = (lucro bruto / Receita) × 100`);
                st(`Substituindo: lucro bruto = ${fmt(receita)} − ${fmt(cmv)}`);
                return `Lucro bruto: ${fmt(receita-cmv)}\nMargem bruta: ${fmt(((receita-cmv)/receita)*100)} %`;
            }
            default: return "Operação financeira inválida.";
        }
    }

    function calculateElectrical(op) {
        if (["RS","RP","CS","CP","LS","LP"].includes(op)) {
            const raw = String(getFormValue("valores"));
            const nums = parseNumbers(raw);
            if (nums.length < 2) return "Informe ao menos 2 valores separados por vírgula.";
            switch(op) {
                case "RS": {
                    st(`Fórmula: Req = R₁ + R₂ + ... + Rₙ (associação em série)`);
                    st(`Expressão: Req = ${nums.map(fmt).join(" + ")}`);
                    let acc = nums[0];
                    for (let i = 1; i < nums.length; i++) { const next = acc + nums[i]; st(`${fmt(acc)} + ${fmt(nums[i])} = ${fmt(next)}`); acc = next; }
                    return `Req (série): ${fmt(acc)} Ω\nValores: ${nums.map(fmt).join(", ")} Ω`;
                }
                case "RP": {
                    st(`Fórmula: 1/Req = 1/R₁ + 1/R₂ + ... + 1/Rₙ (associação em paralelo)`);
                    const invs = nums.map(v => 1 / v);
                    st(`Expressão: 1/Req = ${nums.map(v=>`1/${fmt(v)}`).join(" + ")} = ${invs.map(fmt).join(" + ")}`);
                    let acc = invs[0];
                    for (let i = 1; i < invs.length; i++) { const next = acc + invs[i]; st(`${fmt(acc)} + ${fmt(invs[i])} = ${fmt(next)}`); acc = next; }
                    st(`1/Req = ${fmt(acc)}  →  Req = 1 / ${fmt(acc)}`);
                    return `Req (paralelo): ${fmt(1/acc)} Ω\nValores: ${nums.map(fmt).join(", ")} Ω`;
                }
                case "CS": {
                    st(`Fórmula: 1/Ceq = 1/C₁ + 1/C₂ + ... + 1/Cₙ (capacitores em série)`);
                    const invs = nums.map(v => 1 / v);
                    st(`Expressão: 1/Ceq = ${nums.map(v=>`1/${fmt(v)}`).join(" + ")} = ${invs.map(fmt).join(" + ")}`);
                    let acc = invs[0];
                    for (let i = 1; i < invs.length; i++) { const next = acc + invs[i]; st(`${fmt(acc)} + ${fmt(invs[i])} = ${fmt(next)}`); acc = next; }
                    st(`1/Ceq = ${fmt(acc)}  →  Ceq = 1 / ${fmt(acc)}`);
                    return `Ceq (série): ${fmt(1/acc)} F\nValores: ${nums.map(fmt).join(", ")} F`;
                }
                case "CP": {
                    st(`Fórmula: Ceq = C₁ + C₂ + ... + Cₙ (capacitores em paralelo)`);
                    st(`Expressão: Ceq = ${nums.map(fmt).join(" + ")}`);
                    let acc = nums[0];
                    for (let i = 1; i < nums.length; i++) { const next = acc + nums[i]; st(`${fmt(acc)} + ${fmt(nums[i])} = ${fmt(next)}`); acc = next; }
                    return `Ceq (paralelo): ${fmt(acc)} F\nValores: ${nums.map(fmt).join(", ")} F`;
                }
                case "LS": {
                    st(`Fórmula: Leq = L₁ + L₂ + ... + Lₙ (indutores em série)`);
                    st(`Expressão: Leq = ${nums.map(fmt).join(" + ")}`);
                    let acc = nums[0];
                    for (let i = 1; i < nums.length; i++) { const next = acc + nums[i]; st(`${fmt(acc)} + ${fmt(nums[i])} = ${fmt(next)}`); acc = next; }
                    return `Leq (série): ${fmt(acc)} H\nValores: ${nums.map(fmt).join(", ")} H`;
                }
                case "LP": {
                    st(`Fórmula: 1/Leq = 1/L₁ + 1/L₂ + ... + 1/Lₙ (indutores em paralelo)`);
                    const invs = nums.map(v => 1 / v);
                    st(`Expressão: 1/Leq = ${nums.map(v=>`1/${fmt(v)}`).join(" + ")} = ${invs.map(fmt).join(" + ")}`);
                    let acc = invs[0];
                    for (let i = 1; i < invs.length; i++) { const next = acc + invs[i]; st(`${fmt(acc)} + ${fmt(invs[i])} = ${fmt(next)}`); acc = next; }
                    st(`1/Leq = ${fmt(acc)}  →  Leq = 1 / ${fmt(acc)}`);
                    return `Leq (paralelo): ${fmt(1/acc)} H\nValores: ${nums.map(fmt).join(", ")} H`;
                }
                default: return "Associação inválida.";
            }
        }
        const corrente=rn("corrente"),voltagem=rn("voltagem"),potencia=rn("potencia"),resistencia=rn("resistencia");
        if([corrente,voltagem,potencia,resistencia].some(v=>v===null)) return "Preencha todos os campos.";
        switch(op) {
            case "R":
                if(potencia===0)    { st(`Fórmula: R = V / I (deixando P de fora)`); st(`Substituindo: R = ${fmt(voltagem)} / ${fmt(corrente)}`); return `Resistência: ${fmt(voltagem/corrente)} Ω`; }
                if(corrente===0)    { st(`Fórmula: R = V² / P (deixando I de fora)`); st(`Substituindo: R = (${fmt(voltagem)})² / ${fmt(potencia)}`); return `Resistência: ${fmt(voltagem**2/potencia)} Ω`; }
                if(voltagem===0)    { st(`Fórmula: R = P / I² (deixando V de fora)`); st(`Substituindo: R = ${fmt(potencia)} / (${fmt(corrente)})²`); return `Resistência: ${fmt(potencia/corrente**2)} Ω`; }
                return "Deixe um campo como 0.";
            case "I":
                if(resistencia===0) { st(`Fórmula: I = P / V (deixando R de fora)`); st(`Substituindo: I = ${fmt(potencia)} / ${fmt(voltagem)}`); return `Corrente: ${fmt(potencia/voltagem)} A`; }
                if(voltagem===0)    { st(`Fórmula: I = √(P / R) (deixando V de fora)`); st(`Substituindo: I = √(${fmt(potencia)} / ${fmt(resistencia)})`); return `Corrente: ${fmt(Math.sqrt(potencia/resistencia))} A`; }
                if(potencia===0)    { st(`Fórmula: I = V / R (deixando P de fora)`); st(`Substituindo: I = ${fmt(voltagem)} / ${fmt(resistencia)}`); return `Corrente: ${fmt(voltagem/resistencia)} A`; }
                return "Deixe um campo como 0.";
            case "P":
                if(voltagem===0)    { st(`Fórmula: P = I² × R (deixando V de fora)`); st(`Substituindo: P = (${fmt(corrente)})² × ${fmt(resistencia)}`); return `Potência: ${fmt(corrente**2*resistencia)} W`; }
                if(resistencia===0) { st(`Fórmula: P = V × I (deixando R de fora)`); st(`Substituindo: P = ${fmt(voltagem)} × ${fmt(corrente)}`); return `Potência: ${fmt(voltagem*corrente)} W`; }
                if(corrente===0)    { st(`Fórmula: P = V² / R (deixando I de fora)`); st(`Substituindo: P = (${fmt(voltagem)})² / ${fmt(resistencia)}`); return `Potência: ${fmt(voltagem**2/resistencia)} W`; }
                return "Deixe um campo como 0.";
            case "V":
                if(potencia===0)    { st(`Fórmula: V = R × I (deixando P de fora)`); st(`Substituindo: V = ${fmt(resistencia)} × ${fmt(corrente)}`); return `Voltagem: ${fmt(resistencia*corrente)} V`; }
                if(corrente===0)    { st(`Fórmula: V = √(P × R) (deixando I de fora)`); st(`Substituindo: V = √(${fmt(potencia)} × ${fmt(resistencia)})`); return `Voltagem: ${fmt(Math.sqrt(potencia*resistencia))} V`; }
                if(resistencia===0) { st(`Fórmula: V = P / I (deixando R de fora)`); st(`Substituindo: V = ${fmt(potencia)} / ${fmt(corrente)}`); return `Voltagem: ${fmt(potencia/corrente)} V`; }
                return "Deixe um campo como 0.";
            default: return "Grandeza inválida.";
        }
    }

    function calculatePhysics(op) {
        const g=(n)=>rn(n);
        switch(op){
            case "velocity": {
                const d=g("distancia"),t=g("tempo");
                if(t===0) return "Tempo ≠ 0.";
                st(`Fórmula: v = d / t`);
                st(`Substituindo: v = ${fmt(d)} / ${fmt(t)}`);
                chartPhysicsMotion("velocity", {d, time:t});
                return `Velocidade média: ${fmt(d/t)} m/s`;
            }
            case "acceleration": {
                const vi=g("velocidadeInicial"),vf=g("velocidadeFinal"),t=g("tempo");
                if(t===0) return "Tempo ≠ 0.";
                st(`Fórmula: a = (vf − vi) / t`);
                st(`Substituindo: a = (${fmt(vf)} − ${fmt(vi)}) / ${fmt(t)}`);
                chartPhysicsMotion("acceleration", {vi, vf, time:t});
                return `Aceleração: ${fmt((vf-vi)/t)} m/s²`;
            }
            case "force": {
                const m=g("massa"),a=g("aceleracao");
                st(`Fórmula: F = m × a`);
                st(`Substituindo: F = ${fmt(m)} × ${fmt(a)}`);
                return `Força: ${fmt(m*a)} N`;
            }
            case "work": {
                const f=g("forca"), d=g("distancia");
                st(`Fórmula: W = F × d`);
                st(`Substituindo: W = ${fmt(f)} × ${fmt(d)}`);
                return `Trabalho: ${fmt(f*d)} J`;
            }
            case "pressure": {
                const f=g("forca"),a=g("area");
                if(a===0) return "Área ≠ 0.";
                st(`Fórmula: P = F / A`);
                st(`Substituindo: P = ${fmt(f)} / ${fmt(a)}`);
                return `Pressão: ${fmt(f/a)} Pa`;
            }
            case "density": {
                const m=g("massa"),v=g("volume");
                if(v===0) return "Volume ≠ 0.";
                st(`Fórmula: ρ = m / V`);
                st(`Substituindo: ρ = ${fmt(m)} / ${fmt(v)}`);
                return `Densidade: ${fmt(m/v)} kg/m³`;
            }
            case "power": {
                const tr=g("trabalho"),t=g("tempo");
                if(t===0) return "Tempo ≠ 0.";
                st(`Fórmula: P = τ / t`);
                st(`Substituindo: P = ${fmt(tr)} / ${fmt(t)}`);
                return `Potência: ${fmt(tr/t)} W`;
            }
            case "kinetic": {
                const m=g("massa"),v=g("velocidade");
                st(`Fórmula: Ec = (m × v²) / 2`);
                st(`Substituindo: Ec = (${fmt(m)} × (${fmt(v)})²) / 2 = (${fmt(m)} × ${fmt(v*v)}) / 2`);
                return `Energia cinética: ${fmt((m*v**2)/2)} J`;
            }
            default: return "Fórmula física inválida.";
        }
    }

    function calculateProgression(op) {
        const a1=rn("a1"),r=rn("r"),q=rn("q"),n=rn("n");
        chartProgression(op, a1, r, q, n);
        switch(op){
            case "paTerm": {
                if(!n) return "N ≠ 0.";
                st(`Fórmula: aₙ = a₁ + (n − 1) × r`);
                st(`Substituindo: aₙ = ${fmt(a1)} + (${fmt(n)} − 1) × ${fmt(r)}`);
                return `PA termo geral: ${fmt(a1+(n-1)*r)}`;
            }
            case "paSum": {
                if(!n) return "N ≠ 0.";
                const an=a1+(n-1)*r;
                st(`Fórmula: aₙ = a₁ + (n − 1) × r ; Sₙ = n × (a₁ + aₙ) / 2`);
                st(`Substituindo: aₙ = ${fmt(a1)} + (${fmt(n)} − 1) × ${fmt(r)} = ${fmt(an)}`);
                st(`Sₙ = ${fmt(n)} × (${fmt(a1)} + ${fmt(an)}) / 2`);
                return `PA soma: ${fmt((n*(a1+an))/2)}`;
            }
            case "pgTerm": {
                if(!n) return "N ≠ 0.";
                st(`Fórmula: aₙ = a₁ × q^(n − 1)`);
                st(`Substituindo: aₙ = ${fmt(a1)} × ${fmt(q)}^(${fmt(n)} − 1)`);
                return `PG termo geral: ${fmt(a1*q**(n-1))}`;
            }
            case "pgSum": {
                if(!n) return "N ≠ 0.";
                if(q===1) { st(`Fórmula: q = 1 → Sₙ = a₁ × n`); st(`Substituindo: Sₙ = ${fmt(a1)} × ${fmt(n)}`); return `PG soma: ${fmt(a1*n)}`; }
                st(`Fórmula: Sₙ = a₁ × (qⁿ − 1) / (q − 1)`);
                st(`Substituindo: Sₙ = ${fmt(a1)} × (${fmt(q)}^${fmt(n)} − 1) / (${fmt(q)} − 1)`);
                return `PG soma: ${fmt((a1*(q**n-1))/(q-1))}`;
            }
            case "pgInfinite": {
                if(Math.abs(q)>=1) return "Razão |q| < 1 para soma infinita.";
                st(`Fórmula: S∞ = a₁ / (1 − q)  (válido só para |q| < 1)`);
                st(`Substituindo: S∞ = ${fmt(a1)} / (1 − ${fmt(q)})`);
                return `PG soma infinita: ${fmt(a1/(1-q))}`;
            }
            default: return "Progressão inválida.";
        }
    }

    // ── sub-motor de geometria ────────────────────────────────────

    function calculateGeometry(op) {
        const g = (n) => rn(n);
        switch(op) {
            case "circleArea": {
                const r = g("raio");
                if(r===null) return "Preencha o campo.";
                st(`Fórmula: A = π × r² ; C = 2 × π × r`);
                st(`Substituindo: A = π × (${fmt(r)})² ; C = 2 × π × ${fmt(r)}`);
                return `Área: ${fmt(Math.PI*r*r)}\nCircunferência: ${fmt(2*Math.PI*r)}`;
            }
            case "squareArea": {
                const l = g("lado");
                if(l===null) return "Preencha o campo.";
                st(`Fórmula: A = l² ; P = 4 × l ; d = l × √2`);
                st(`Substituindo: A = (${fmt(l)})² ; P = 4 × ${fmt(l)} ; d = ${fmt(l)} × √2`);
                return `Área: ${fmt(l*l)}\nPerímetro: ${fmt(4*l)}\nDiagonal: ${fmt(l*Math.SQRT2)}`;
            }
            case "rectArea": {
                const b=g("base"), a=g("altura");
                if(b===null||a===null) return "Preencha todos os campos.";
                st(`Fórmula: A = b × a ; P = 2 × (b + a) ; d = √(b² + a²)`);
                st(`Substituindo: A = ${fmt(b)} × ${fmt(a)} ; P = 2 × (${fmt(b)} + ${fmt(a)}) ; d = √((${fmt(b)})² + (${fmt(a)})²)`);
                return `Área: ${fmt(b*a)}\nPerímetro: ${fmt(2*(b+a))}\nDiagonal: ${fmt(Math.sqrt(b*b+a*a))}`;
            }
            case "triangleArea": {
                const b=g("base"), a=g("altura");
                if(b===null||a===null) return "Preencha todos os campos.";
                st(`Fórmula: A = (b × a) / 2`);
                st(`Substituindo: A = (${fmt(b)} × ${fmt(a)}) / 2`);
                return `Área: ${fmt((b*a)/2)}`;
            }
            case "triangleHeron": {
                const a=g("ladoA"), b=g("ladoB"), c=g("ladoC");
                if(a===null||b===null||c===null) return "Preencha todos os campos.";
                const p=(a+b+c)/2;
                st(`Fórmula: p = (a + b + c) / 2 ; A = √(p(p−a)(p−b)(p−c))  (Heron)`);
                st(`Substituindo: p = (${fmt(a)} + ${fmt(b)} + ${fmt(c)}) / 2 = ${fmt(p)}`);
                st(`A = √(${fmt(p)} × ${fmt(p-a)} × ${fmt(p-b)} × ${fmt(p-c)})`);
                const area=Math.sqrt(p*(p-a)*(p-b)*(p-c));
                return `Área (Heron): ${fmt(area)}`;
            }
            case "trapezoid": {
                const B=g("baseMaior"), b=g("baseMenor"), a=g("altura");
                if(B===null||b===null||a===null) return "Preencha todos os campos.";
                st(`Fórmula: A = ((B + b) × a) / 2`);
                st(`Substituindo: A = ((${fmt(B)} + ${fmt(b)}) × ${fmt(a)}) / 2`);
                return `Área: ${fmt(((B+b)*a)/2)}`;
            }
            case "rhombus": {
                const d1=g("d1"), d2=g("d2");
                if(d1===null||d2===null) return "Preencha todos os campos.";
                st(`Fórmula: A = (D × d) / 2 ; lado = √((D/2)² + (d/2)²)`);
                st(`Substituindo: A = (${fmt(d1)} × ${fmt(d2)}) / 2`);
                return `Área: ${fmt((d1*d2)/2)}\nLado: ${fmt(Math.sqrt((d1/2)**2+(d2/2)**2))}`;
            }
            case "regularPolygon": {
                const n=g("lados"), l=g("lado");
                if(n===null||l===null||n<3) return "Informe nº de lados ≥ 3.";
                st(`Fórmula: apótema = l / (2 × tan(π/n)) ; A = (n × l × apótema) / 2 ; P = n × l`);
                const ap=l/(2*Math.tan(Math.PI/n));
                st(`Substituindo: apótema = ${fmt(l)} / (2 × tan(π/${fmt(n)})) = ${fmt(ap)}`);
                st(`A = (${fmt(n)} × ${fmt(l)} × ${fmt(ap)}) / 2`);
                return `Área: ${fmt((n*l*ap)/2)}\nPerímetro: ${fmt(n*l)}`;
            }
            case "ellipseArea": {
                const a=g("semiEixoA"), b=g("semiEixoB");
                if(a===null||b===null) return "Preencha todos os campos.";
                st(`Fórmula: A = π × a × b`);
                st(`Substituindo: A = π × ${fmt(a)} × ${fmt(b)}`);
                return `Área: ${fmt(Math.PI*a*b)}`;
            }
            case "sectorArea": {
                const r=g("raio"), ang=g("angulo");
                if(r===null||ang===null) return "Preencha todos os campos.";
                const rad=ang*Math.PI/180;
                st(`Fórmula: ângulo(rad) = ângulo° × π/180 ; A = (rad × r²) / 2 ; arco = r × rad`);
                st(`Substituindo: rad = ${fmt(ang)} × π/180 = ${fmt(rad)}`);
                st(`A = (${fmt(rad)} × (${fmt(r)})²) / 2`);
                return `Área: ${fmt((rad*r*r)/2)}\nArco: ${fmt(r*rad)}`;
            }
            case "sphereVol": {
                const r=g("raio");
                if(r===null) return "Preencha o campo.";
                st(`Fórmula: V = (4/3) × π × r³ ; A = 4 × π × r²`);
                st(`Substituindo: V = (4/3) × π × (${fmt(r)})³ ; A = 4 × π × (${fmt(r)})²`);
                return `Volume: ${fmt((4/3)*Math.PI*r**3)}\nÁrea: ${fmt(4*Math.PI*r*r)}`;
            }
            case "cubeVol": {
                const a=g("aresta");
                if(a===null) return "Preencha o campo.";
                st(`Fórmula: V = a³ ; A = 6 × a² ; d = a × √3`);
                st(`Substituindo: V = (${fmt(a)})³ ; A = 6 × (${fmt(a)})² ; d = ${fmt(a)} × √3`);
                return `Volume: ${fmt(a**3)}\nÁrea: ${fmt(6*a*a)}\nDiagonal: ${fmt(a*Math.sqrt(3))}`;
            }
            case "boxVol": {
                const c=g("comprimento"), l=g("largura"), a=g("altura");
                if(c===null||l===null||a===null) return "Preencha todos os campos.";
                st(`Fórmula: V = c × l × a ; A = 2 × (c×l + c×a + l×a)`);
                st(`Substituindo: V = ${fmt(c)} × ${fmt(l)} × ${fmt(a)}`);
                return `Volume: ${fmt(c*l*a)}\nÁrea: ${fmt(2*(c*l+c*a+l*a))}`;
            }
            case "cylinderVol": {
                const r=g("raio"), a=g("altura");
                if(r===null||a===null) return "Preencha todos os campos.";
                st(`Fórmula: V = π × r² × a ; A = 2 × π × r × (r + a)`);
                st(`Substituindo: V = π × (${fmt(r)})² × ${fmt(a)}`);
                return `Volume: ${fmt(Math.PI*r*r*a)}\nÁrea: ${fmt(2*Math.PI*r*(r+a))}`;
            }
            case "coneVol": {
                const r=g("raio"), a=g("altura");
                if(r===null||a===null) return "Preencha todos os campos.";
                const g_=Math.sqrt(r*r+a*a);
                st(`Fórmula: geratriz = √(r² + a²) ; V = (1/3) × π × r² × a ; A = π × r × (r + geratriz)`);
                st(`Substituindo: geratriz = √((${fmt(r)})² + (${fmt(a)})²) = ${fmt(g_)}`);
                st(`V = (1/3) × π × (${fmt(r)})² × ${fmt(a)}`);
                return `Volume: ${fmt((1/3)*Math.PI*r*r*a)}\nGeratriz: ${fmt(g_)}\nÁrea: ${fmt(Math.PI*r*(r+g_))}`;
            }
            case "pyramidVol": {
                const l=g("ladoBase"), a=g("altura");
                if(l===null||a===null) return "Preencha todos os campos.";
                st(`Fórmula: V = (1/3) × l² × a`);
                st(`Substituindo: V = (1/3) × (${fmt(l)})² × ${fmt(a)}`);
                return `Volume: ${fmt((1/3)*l*l*a)}`;
            }
            case "torusVol": {
                const R=g("R"), r=g("r");
                if(R===null||r===null) return "Preencha todos os campos.";
                st(`Fórmula: V = 2 × π² × R × r² ; A = 4 × π² × R × r`);
                st(`Substituindo: V = 2 × π² × ${fmt(R)} × (${fmt(r)})²`);
                return `Volume: ${fmt(2*Math.PI*Math.PI*R*r*r)}\nÁrea: ${fmt(4*Math.PI*Math.PI*R*r)}`;
            }
            default: return "Geometria inválida.";
        }
    }

    // ── sub-motor de engenharia ──────────────────────────────────

    function calculateEngineering(op) {
        const g=(n)=>rn(n);
        switch(op){
            case "tensao": {
                const f=g("forca"), a=g("area");
                if(f===null||a===null||a===0) return "Área ≠ 0.";
                st(`Fórmula: σ = F / A`);
                st(`Substituindo: σ = ${fmt(f)} / ${fmt(a)}`);
                return `Tensão σ: ${fmt(f/a)} Pa`;
            }
            case "deformacao": {
                const d=g("deltaL"), L=g("L");
                if(d===null||L===null||L===0) return "L ≠ 0.";
                st(`Fórmula: ε = ΔL / L`);
                st(`Substituindo: ε = ${fmt(d)} / ${fmt(L)}`);
                return `Deformação ε: ${fmt(d/L)} (adimensional)`;
            }
            case "modElastico": {
                const t=g("tensao"), d=g("deformacao");
                if(t===null||d===null||d===0) return "Deformação ≠ 0.";
                st(`Fórmula: E = σ / ε`);
                st(`Substituindo: E = ${fmt(t)} / ${fmt(d)}`);
                return `Módulo E: ${fmt(t/d)} Pa`;
            }
            case "momentoFletor": {
                const M=g("momento"), c=g("c"), I=g("inercia");
                if(M===null||c===null||I===null||I===0) return "I ≠ 0.";
                st(`Fórmula: σ = M × c / I`);
                st(`Substituindo: σ = ${fmt(M)} × ${fmt(c)} / ${fmt(I)}`);
                return `σ = M·c/I: ${fmt(M*c/I)} Pa`;
            }
            case "cisalhamento": {
                const f=g("forca"), a=g("area");
                if(f===null||a===null||a===0) return "Área ≠ 0.";
                st(`Fórmula: τ = F / A`);
                st(`Substituindo: τ = ${fmt(f)} / ${fmt(a)}`);
                return `τ: ${fmt(f/a)} Pa`;
            }
            case "torque": {
                const T=g("torque"), r=g("raio"), J=g("J");
                if(T===null||r===null||J===null||J===0) return "J ≠ 0.";
                st(`Fórmula: τ = T × r / J`);
                st(`Substituindo: τ = ${fmt(T)} × ${fmt(r)} / ${fmt(J)}`);
                return `τ = T·r/J: ${fmt(T*r/J)} Pa`;
            }
            case "flambagem": {
                const E=g("E"), I=g("I"), Le=g("Le");
                if(E===null||I===null||Le===null||Le===0) return "Le ≠ 0.";
                st(`Fórmula: Pcr = (π² × E × I) / Le²`);
                st(`Substituindo: Pcr = (π² × ${fmt(E)} × ${fmt(I)}) / (${fmt(Le)})²`);
                return `Carga crítica: ${fmt((Math.PI*Math.PI*E*I)/(Le*Le))} N`;
            }
            case "calorQ": {
                const m=g("massa"), c=g("calor_esp"), dT=g("deltaT");
                if(m===null||c===null||dT===null) return "Preencha todos os campos.";
                st(`Fórmula: Q = m × c × ΔT`);
                st(`Substituindo: Q = ${fmt(m)} × ${fmt(c)} × ${fmt(dT)}`);
                return `Q = m·c·ΔT: ${fmt(m*c*dT)} J`;
            }
            case "dilatacao": {
                const al=g("alfa"), L=g("L"), dT=g("deltaT");
                if(al===null||L===null||dT===null) return "Preencha todos os campos.";
                st(`Fórmula: ΔL = α × L × ΔT`);
                st(`Substituindo: ΔL = ${fmt(al)} × ${fmt(L)} × ${fmt(dT)}`);
                return `ΔL = α·L·ΔT: ${fmt(al*L*dT)} m`;
            }
            case "rendimento": {
                const u=g("potUtil"), t=g("potTotal");
                if(u===null||t===null||t===0) return "Potência total ≠ 0.";
                st(`Fórmula: rendimento = (Potência útil / Potência total) × 100`);
                st(`Substituindo: rendimento = (${fmt(u)} / ${fmt(t)}) × 100`);
                return `Rendimento: ${fmt((u/t)*100)} %`;
            }
            case "vazao": {
                const a=g("area"), v=g("velocidade");
                if(a===null||v===null) return "Preencha todos os campos.";
                st(`Fórmula: Q = A × v`);
                st(`Substituindo: Q = ${fmt(a)} × ${fmt(v)}`);
                return `Vazão Q = A·v: ${fmt(a*v)} m³/s`;
            }
            case "reynolds": {
                const rho=g("rho"), v=g("v"), D=g("D"), mu=g("mu");
                if(rho===null||v===null||D===null||mu===null||mu===0) return "Viscosidade ≠ 0.";
                st(`Fórmula: Re = (ρ × v × D) / μ`);
                st(`Substituindo: Re = (${fmt(rho)} × ${fmt(v)} × ${fmt(D)}) / ${fmt(mu)}`);
                return `Re = ρ·v·D/μ: ${fmt((rho*v*D)/mu)}`;
            }
            case "bernoulli": {
                const p1=g("p1"), rho=g("rho"), v1=g("v1"), v2=g("v2");
                if(p1===null||rho===null||v1===null||v2===null) return "Preencha todos os campos.";
                st(`Fórmula: p2 ≈ p1 + ½ × ρ × (v1² − v2²)`);
                st(`Substituindo: p2 = ${fmt(p1)} + 0,5 × ${fmt(rho)} × ((${fmt(v1)})² − (${fmt(v2)})²)`);
                return `p2 ≈ p1 + ½·ρ·(v1²−v2²): ${fmt(p1+0.5*rho*(v1*v1-v2*v2))} Pa`;
            }
            case "pressHidro": {
                const rho=g("rho"), h=g("h");
                if(rho===null||h===null) return "Preencha todos os campos.";
                st(`Fórmula: p = ρ × g × h  (g = 9,80665 m/s²)`);
                st(`Substituindo: p = ${fmt(rho)} × 9,80665 × ${fmt(h)}`);
                return `p = ρ·g·h: ${fmt(rho*9.80665*h)} Pa`;
            }
            case "capacitor": {
                const C=g("C"), V=g("V");
                if(C===null||V===null) return "Preencha todos os campos.";
                st(`Fórmula: E = ½ × C × V²`);
                st(`Substituindo: E = 0,5 × ${fmt(C)} × (${fmt(V)})²`);
                return `E = ½·C·V²: ${fmt(0.5*C*V*V)} J`;
            }
            case "indutor": {
                const L=g("L_ind"), I=g("I");
                if(L===null||I===null) return "Preencha todos os campos.";
                st(`Fórmula: E = ½ × L × I²`);
                st(`Substituindo: E = 0,5 × ${fmt(L)} × (${fmt(I)})²`);
                return `E = ½·L·I²: ${fmt(0.5*L*I*I)} J`;
            }
            case "reatorLC": {
                const L=g("L_ind"), C=g("C");
                if(L===null||C===null||L===0||C===0) return "L e C ≠ 0.";
                st(`Fórmula: f₀ = 1 / (2π × √(L × C))`);
                st(`Substituindo: f₀ = 1 / (2π × √(${fmt(L)} × ${fmt(C)}))`);
                return `f₀ = 1/(2π√LC): ${fmt(1/(2*Math.PI*Math.sqrt(L*C)))} Hz`;
            }
            case "divisorTensao": {
                const Vin=g("Vin"), R1=g("R1"), R2=g("R2");
                if(Vin===null||R1===null||R2===null) return "Preencha todos os campos.";
                st(`Fórmula: Vout = Vin × R2 / (R1 + R2)`);
                st(`Substituindo: Vout = ${fmt(Vin)} × ${fmt(R2)} / (${fmt(R1)} + ${fmt(R2)})`);
                return `Vout = Vin·R2/(R1+R2): ${fmt(Vin*R2/(R1+R2))} V`;
            }
            case "cargaDistribuida": {
                const w=g("w"), L=g("L");
                if(w===null||L===null) return "Preencha todos os campos.";
                st(`Fórmula: R = (w × L) / 2  (reação em cada apoio)`);
                st(`Substituindo: R = (${fmt(w)} × ${fmt(L)}) / 2`);
                return `Reações: R = R = ${fmt((w*L)/2)} N (cada apoio)`;
            }
            case "momentoMax": {
                const w=g("w"), L=g("L");
                if(w===null||L===null) return "Preencha todos os campos.";
                st(`Fórmula: Mmáx = (w × L²) / 8`);
                st(`Substituindo: Mmáx = (${fmt(w)} × (${fmt(L)})²) / 8`);
                return `Mmáx = w·L²/8: ${fmt((w*L*L)/8)} N·m`;
            }
            case "inerciRetangulo": {
                const b=g("base"), h=g("altura");
                if(b===null||h===null) return "Preencha todos os campos.";
                st(`Fórmula: I = (b × h³) / 12`);
                st(`Substituindo: I = (${fmt(b)} × (${fmt(h)})³) / 12`);
                return `I = b·h³/12: ${fmt((b*h**3)/12)} m⁴`;
            }
            case "inerciCirculo": {
                const r=g("raio");
                if(r===null) return "Preencha o campo.";
                st(`Fórmula: I = (π × r⁴) / 4`);
                st(`Substituindo: I = (π × (${fmt(r)})⁴) / 4`);
                return `I = π·r⁴/4: ${fmt((Math.PI*r**4)/4)} m⁴`;
            }
            case "convTemp": {
                const v=g("valor"), d=g("de");
                if(v===null||d===null) return "Preencha todos os campos.";
                if(d===0) { st(`Fórmula: °F = °C × 9/5 + 32 ; K = °C + 273,15`); st(`Substituindo: °F = ${fmt(v)} × 9/5 + 32 ; K = ${fmt(v)} + 273,15`); return `${v} °C = ${fmt(v*9/5+32)} °F = ${fmt(v+273.15)} K`; }
                if(d===1) { st(`Fórmula: °C = (°F − 32) × 5/9 ; K = °C + 273,15`); st(`Substituindo: °C = (${fmt(v)} − 32) × 5/9`); return `${v} °F = ${fmt((v-32)*5/9)} °C = ${fmt((v-32)*5/9+273.15)} K`; }
                if(d===2) { st(`Fórmula: °C = K − 273,15 ; °F = °C × 9/5 + 32`); st(`Substituindo: °C = ${fmt(v)} − 273,15`); return `${v} K = ${fmt(v-273.15)} °C = ${fmt((v-273.15)*9/5+32)} °F`; }
                return "De: 0=°C  1=°F  2=K";
            }
            case "convPressao": {
                const v=g("valor");
                if(v===null) return "Preencha o campo.";
                st(`Fórmula: 1 kPa = 1000 Pa ; 1 bar = 1e5 Pa ; 1 atm = 101.325 Pa ; 1 psi = 6.894,76 Pa`);
                st(`Substituindo: ${fmt(v)} Pa ÷ cada fator de conversão`);
                return `${fmt(v)} Pa\n= ${fmt(v/1000)} kPa\n= ${fmt(v/1e5)} bar\n= ${fmt(v/101325)} atm\n= ${fmt(v/6894.76)} psi`;
            }
            default: return "Engenharia inválida.";
        }
    }

    // ── trigonometria ──────────────────────────────────────────────
    function calculateTrig(op) {
        const toRad = deg => deg * Math.PI / 180;
        const g = (n) => rn(n);
        switch (op) {
            case "sin": {
                const ang = g("angulo");
                if (ang === null) return "Preencha o ângulo.";
                st(`Fórmula: sen(x)`);
                st(`Substituindo: sen(${fmt(ang)}°)`);
                chartTrig("sin", ang);
                return `sen(${fmt(ang)}°) = ${fmt(Math.sin(toRad(ang)))}`;
            }
            case "cos": {
                const ang = g("angulo");
                if (ang === null) return "Preencha o ângulo.";
                st(`Fórmula: cos(x)`);
                st(`Substituindo: cos(${fmt(ang)}°)`);
                chartTrig("cos", ang);
                return `cos(${fmt(ang)}°) = ${fmt(Math.cos(toRad(ang)))}`;
            }
            case "tan": {
                const ang = g("angulo");
                if (ang === null) return "Preencha o ângulo.";
                if (Math.abs(Math.cos(toRad(ang))) < 1e-9) return "Tangente indefinida nesse ângulo (90° + 180°k).";
                st(`Fórmula: tan(x) = sen(x) / cos(x)`);
                st(`Substituindo: tan(${fmt(ang)}°) = sen(${fmt(ang)}°) / cos(${fmt(ang)}°) = ${fmt(Math.sin(toRad(ang)))} / ${fmt(Math.cos(toRad(ang)))}`);
                chartTrig("tan", ang);
                return `tan(${fmt(ang)}°) = ${fmt(Math.tan(toRad(ang)))}`;
            }
            case "cot": {
                const ang = g("angulo");
                if (ang === null) return "Preencha o ângulo.";
                if (Math.abs(Math.sin(toRad(ang))) < 1e-9) return "Cotangente indefinida nesse ângulo (0° + 180°k).";
                st(`Fórmula: cotg(x) = cos(x) / sen(x)`);
                st(`Substituindo: cotg(${fmt(ang)}°) = cos(${fmt(ang)}°) / sen(${fmt(ang)}°) = ${fmt(Math.cos(toRad(ang)))} / ${fmt(Math.sin(toRad(ang)))}`);
                chartTrig("cot", ang);
                return `cotg(${fmt(ang)}°) = ${fmt(1 / Math.tan(toRad(ang)))}`;
            }
            case "lawSines": {
                const a = g("ladoA"), A = g("anguloA"), B = g("anguloB");
                if (a === null || A === null || B === null) return "Preencha todos os campos.";
                if (A <= 0 || A >= 180 || B <= 0 || B >= 180) return "Ângulos devem estar entre 0° e 180°.";
                st(`Fórmula (Lei dos Senos): a / sen(A) = b / sen(B)  →  b = a × sen(B) / sen(A)`);
                st(`Substituindo: b = ${fmt(a)} × sen(${fmt(B)}°) / sen(${fmt(A)}°) = ${fmt(a)} × ${fmt(Math.sin(toRad(B)))} / ${fmt(Math.sin(toRad(A)))}`);
                const b = a * Math.sin(toRad(B)) / Math.sin(toRad(A));
                return `Lado desconhecido: ${fmt(b)}`;
            }
            case "lawCosines": {
                const b = g("ladoB"), c = g("ladoC"), A = g("anguloA");
                if (b === null || c === null || A === null) return "Preencha todos os campos.";
                st(`Fórmula (Lei dos Cossenos): a² = b² + c² − 2 × b × c × cos(A)`);
                st(`Substituindo: a² = (${fmt(b)})² + (${fmt(c)})² − 2 × ${fmt(b)} × ${fmt(c)} × cos(${fmt(A)}°)`);
                const a2 = b * b + c * c - 2 * b * c * Math.cos(toRad(A));
                if (a2 < 0) return "Valores inválidos (resultado negativo).";
                st(`a² = ${fmt(a2)}  →  a = √${fmt(a2)}`);
                return `Lado desconhecido: ${fmt(Math.sqrt(a2))}`;
            }
            case "convertAngle": {
                const valor = g("valor"), de = g("de");
                if (valor === null || de === null) return "Preencha todos os campos.";
                if (de === 0) { st(`Fórmula: rad = graus × π / 180`); st(`Substituindo: rad = ${fmt(valor)} × π / 180`); return `Em radianos: ${fmt(valor * Math.PI / 180)}`; }
                if (de === 1) { st(`Fórmula: graus = rad × 180 / π`); st(`Substituindo: graus = ${fmt(valor)} × 180 / π`); return `Em graus: ${fmt(valor * 180 / Math.PI)}`; }
                return "Preencha 'De' com 0 (graus) ou 1 (radianos).";
            }
            default: return "Trigonometria inválida.";
        }
    }

    // ── conversor de unidades (comprimento, massa, temperatura, ângulo) ──────
    function calculateUnits(op) {
        const valor = rn("valor");
        const de = getFormValue("de");
        const para = getFormValue("para");
        if (valor === null || !de || !para) return "Preencha todos os campos.";
        const labelOf = (choices, code) => choices.find(c => c.value === code)?.label || code;

        if (op === "length" || op === "mass") {
            const table = op === "length" ? lengthUnits : massUnits;
            const choices = op === "length" ? lengthChoices : massChoices;
            if (!(de in table) || !(para in table)) return "Unidade inválida.";
            st(`Fórmula: valor(unidade base) = valor × fator(de) ; resultado = valor(base) / fator(para)`);
            st(`Substituindo: base = ${fmt(valor)} × ${table[de]} = ${fmt(valor * table[de])}`);
            st(`resultado = ${fmt(valor * table[de])} / ${table[para]}`);
            const resultado = (valor * table[de]) / table[para];
            return `${fmt(valor)} ${labelOf(choices, de)} = ${fmt(resultado)} ${labelOf(choices, para)}`;
        }

        if (op === "angle") {
            let resultado;
            if (de === para) { st(`Como a unidade de origem e destino são iguais, o valor não muda.`); resultado = valor; }
            else if (de === "deg" && para === "rad") { st(`Fórmula: rad = graus × π / 180`); st(`Substituindo: rad = ${fmt(valor)} × π / 180`); resultado = valor * Math.PI / 180; }
            else if (de === "rad" && para === "deg") { st(`Fórmula: graus = rad × 180 / π`); st(`Substituindo: graus = ${fmt(valor)} × 180 / π`); resultado = valor * 180 / Math.PI; }
            else return "Unidade de ângulo inválida.";
            return `${fmt(valor)} ${labelOf(angleUnitChoices, de)} = ${fmt(resultado)} ${labelOf(angleUnitChoices, para)}`;
        }

        if (op === "temperature") {
            let celsius;
            if (de === "C") { st(`Como a origem já está em Celsius, não precisa converter.`); celsius = valor; }
            else if (de === "F") { st(`Fórmula: °C = (°F − 32) × 5/9`); st(`Substituindo: °C = (${fmt(valor)} − 32) × 5/9`); celsius = (valor - 32) * 5 / 9; }
            else if (de === "K") { st(`Fórmula: °C = K − 273,15`); st(`Substituindo: °C = ${fmt(valor)} − 273,15`); celsius = valor - 273.15; }
            else return "Unidade de origem inválida.";
            let resultado;
            if (para === "C") { st(`Como o destino é Celsius, o valor em Celsius já é o resultado.`); resultado = celsius; }
            else if (para === "F") { st(`Fórmula: °F = °C × 9/5 + 32`); st(`Substituindo: °F = ${fmt(celsius)} × 9/5 + 32`); resultado = celsius * 9 / 5 + 32; }
            else if (para === "K") { st(`Fórmula: K = °C + 273,15`); st(`Substituindo: K = ${fmt(celsius)} + 273,15`); resultado = celsius + 273.15; }
            else return "Unidade de destino inválida.";
            return `${fmt(valor)} ${labelOf(tempChoices, de)} = ${fmt(resultado)} ${labelOf(tempChoices, para)}`;
        }

        return "Conversão inválida.";
    }

    // ── estatística descritiva ──────────────────────────────────────
    function calculateStatistics(op) {
        const nums = parseNumbers(getFormValue("valores"));
        if (nums.length < 1) return "Informe ao menos 1 valor, separado por vírgula.";
        const n = nums.length;
        const mean = nums.reduce((a, v) => a + v, 0) / n;
        switch (op) {
            case "mean": {
                st(`Fórmula: média = (soma dos valores) / n`);
                st(`Expressão: soma = ${nums.map(fmt).join(" + ")}`);
                let acc = nums[0];
                for (let i = 1; i < nums.length; i++) { const next = acc + nums[i]; st(`${fmt(acc)} + ${fmt(nums[i])} = ${fmt(next)}`); acc = next; }
                st(`soma = ${fmt(acc)}  →  média = ${fmt(acc)} / ${n}`);
                chartStatistics(nums, mean);
                return `Média: ${fmt(mean)}`;
            }
            case "median": {
                const sorted = [...nums].sort((a, b) => a - b);
                const mid = Math.floor(n / 2);
                st(`Fórmula: mediana = valor central da lista ordenada (ou média dos 2 centrais, se n for par)`);
                st(`Valores ordenados: ${sorted.map(fmt).join(", ")}`);
                const median = n % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
                if (n % 2 === 0) st(`n par: mediana = (${fmt(sorted[mid-1])} + ${fmt(sorted[mid])}) / 2`);
                else st(`n ímpar: mediana = valor da posição central = ${fmt(sorted[mid])}`);
                chartStatistics(nums, mean);
                return `Mediana: ${fmt(median)}`;
            }
            case "mode": {
                const freq = {};
                nums.forEach(v => { freq[v] = (freq[v] || 0) + 1; });
                const maxFreq = Math.max(...Object.values(freq));
                st(`Fórmula: moda = valor(es) que mais se repete(m)`);
                st(`Frequências: ${Object.entries(freq).map(([k,v])=>`${fmt(Number(k))}×${v}`).join(", ")}`);
                chartStatistics(nums, mean);
                if (maxFreq <= 1) return "Não há moda (todos os valores aparecem uma vez).";
                const modes = Object.keys(freq).filter(k => freq[k] === maxFreq).map(Number);
                return `Moda: ${modes.map(fmt).join(", ")}`;
            }
            case "stdDev": {
                if (n < 2) return "Informe ao menos 2 valores.";
                st(`Fórmula: desvio padrão = √variância ; variância = Σ(x − média)² / n`);
                st(`Média = ${fmt(mean)}`);
                st(`Substituindo: variância = (${nums.map(v=>`(${fmt(v)}−${fmt(mean)})²`).join(" + ")}) / ${n}`);
                const variance = nums.reduce((a, v) => a + (v - mean) ** 2, 0) / n;
                st(`variância = ${fmt(variance)}  →  desvio padrão = √${fmt(variance)}`);
                chartStatistics(nums, mean);
                return `Desvio padrão: ${fmt(Math.sqrt(variance))}`;
            }
            case "variance": {
                if (n < 2) return "Informe ao menos 2 valores.";
                st(`Fórmula: variância = Σ(x − média)² / n`);
                st(`Média = ${fmt(mean)}`);
                st(`Substituindo: variância = (${nums.map(v=>`(${fmt(v)}−${fmt(mean)})²`).join(" + ")}) / ${n}`);
                const variance = nums.reduce((a, v) => a + (v - mean) ** 2, 0) / n;
                chartStatistics(nums, mean);
                return `Variância: ${fmt(variance)}`;
            }
            default: return "Estatística inválida.";
        }
    }

    // ── combinatória / probabilidade ─────────────────────────────────
    function factorial(n) {
        if (n < 0 || !Number.isInteger(n)) return NaN;
        let result = 1;
        for (let i = 2; i <= n; i++) result *= i;
        return result;
    }
    function calculateCombinatorics(op) {
        const g = (n) => rn(n);
        switch (op) {
            case "factorial": {
                const n = g("n");
                if (n === null) return "Preencha n.";
                if (n < 0 || !Number.isInteger(n)) return "n deve ser um inteiro ≥ 0.";
                if (n > 170) return "n muito grande (estoura o limite numérico).";
                st(`Fórmula: n! = n × (n−1) × (n−2) × ... × 1`);
                if (n <= 1) { st(`${fmt(n)}! = 1 (por definição)`); }
                else {
                    const terms = Array.from({length:n},(_,i)=>n-i);
                    st(`Expressão: ${fmt(n)}! = ${terms.join(" × ")}`);
                    let acc = terms[0];
                    for (let i = 1; i < terms.length; i++) { const next = acc * terms[i]; st(`${fmt(acc)} × ${fmt(terms[i])} = ${fmt(next)}`); acc = next; }
                }
                return `${fmt(n)}! = ${fmt(factorial(n))}`;
            }
            case "permutation": {
                const n = g("n"), x = g("x");
                if (n === null || x === null) return "Preencha n e x.";
                if (!Number.isInteger(n) || !Number.isInteger(x) || n < 0 || x < 0 || x > n) return "Valores inválidos (0 ≤ x ≤ n, inteiros).";
                st(`Fórmula: A(n,x) = n! / (n − x)!`);
                st(`Substituindo: A(${fmt(n)},${fmt(x)}) = ${fmt(n)}! / (${fmt(n)} − ${fmt(x)})! = ${fmt(factorial(n))} / ${fmt(factorial(n-x))}`);
                return `A(${fmt(n)},${fmt(x)}) = ${fmt(factorial(n) / factorial(n - x))}`;
            }
            case "combination": {
                const n = g("n"), x = g("x");
                if (n === null || x === null) return "Preencha n e x.";
                if (!Number.isInteger(n) || !Number.isInteger(x) || n < 0 || x < 0 || x > n) return "Valores inválidos (0 ≤ x ≤ n, inteiros).";
                st(`Fórmula: C(n,x) = n! / (x! × (n − x)!)`);
                st(`Substituindo: C(${fmt(n)},${fmt(x)}) = ${fmt(n)}! / (${fmt(x)}! × (${fmt(n)} − ${fmt(x)})!) = ${fmt(factorial(n))} / (${fmt(factorial(x))} × ${fmt(factorial(n-x))})`);
                return `C(${fmt(n)},${fmt(x)}) = ${fmt(factorial(n) / (factorial(x) * factorial(n - x)))}`;
            }
            default: return "Combinatória inválida.";
        }
    }

    // ── matrizes ──────────────────────────────────────────────────────
    function calculateMatrices(op) {
        const parseMatrix = (name, size) => {
            const cells = [];
            for (let i = 0; i < size; i++) {
                const v = rn(`${name}_${i}`);
                if (v === null) return null;
                cells.push(v);
            }
            return cells;
        };
        switch (op) {
            case "sum2x2": {
                const a = parseMatrix("m1", 4), b = parseMatrix("m2", 4);
                if (!a || !b) return "Preencha todos os quadradinhos das duas matrizes.";
                st(`Fórmula: soma elemento a elemento (mesma posição)`);
                st(`Substituindo: [${fmt(a[0])}+${fmt(b[0])}, ${fmt(a[1])}+${fmt(b[1])}] / [${fmt(a[2])}+${fmt(b[2])}, ${fmt(a[3])}+${fmt(b[3])}]`);
                const r = a.map((v, i) => v + b[i]);
                return `Resultado:\n[${fmt(r[0])}, ${fmt(r[1])}]\n[${fmt(r[2])}, ${fmt(r[3])}]`;
            }
            case "mult2x2": {
                const a = parseMatrix("m1", 4), b = parseMatrix("m2", 4);
                if (!a || !b) return "Preencha todos os quadradinhos das duas matrizes.";
                const [a11, a12, a21, a22] = a, [b11, b12, b21, b22] = b;
                st(`Fórmula: cada elemento = linha de A × coluna de B`);
                st(`r11 = ${fmt(a11)}×${fmt(b11)} + ${fmt(a12)}×${fmt(b21)} ; r12 = ${fmt(a11)}×${fmt(b12)} + ${fmt(a12)}×${fmt(b22)}`);
                st(`r21 = ${fmt(a21)}×${fmt(b11)} + ${fmt(a22)}×${fmt(b21)} ; r22 = ${fmt(a21)}×${fmt(b12)} + ${fmt(a22)}×${fmt(b22)}`);
                const r11 = a11 * b11 + a12 * b21, r12 = a11 * b12 + a12 * b22;
                const r21 = a21 * b11 + a22 * b21, r22 = a21 * b12 + a22 * b22;
                return `Resultado:\n[${fmt(r11)}, ${fmt(r12)}]\n[${fmt(r21)}, ${fmt(r22)}]`;
            }
            case "det2x2": {
                const a = parseMatrix("m1", 4);
                if (!a) return "Preencha todos os quadradinhos da matriz.";
                const [a11, a12, a21, a22] = a;
                st(`Fórmula: det = a11×a22 − a12×a21`);
                st(`Substituindo: det = ${fmt(a11)}×${fmt(a22)} − ${fmt(a12)}×${fmt(a21)} = ${fmt(a11*a22)} − ${fmt(a12*a21)}`);
                return `Determinante: ${fmt(a11 * a22 - a12 * a21)}`;
            }
            case "det3x3": {
                const a = parseMatrix("m1", 9);
                if (!a) return "Preencha todos os quadradinhos da matriz.";
                const [a11, a12, a13, a21, a22, a23, a31, a32, a33] = a;
                st(`Fórmula (regra de Sarrus/cofatores): det = a11(a22a33−a23a32) − a12(a21a33−a23a31) + a13(a21a32−a22a31)`);
                const t1 = a22*a33-a23*a32, t2 = a21*a33-a23*a31, t3 = a21*a32-a22*a31;
                st(`Substituindo: det = ${fmt(a11)}×(${fmt(t1)}) − ${fmt(a12)}×(${fmt(t2)}) + ${fmt(a13)}×(${fmt(t3)})`);
                const det = a11 * t1 - a12 * t2 + a13 * t3;
                return `Determinante: ${fmt(det)}`;
            }
            default: return "Operação de matriz inválida.";
        }
    }

    // ── dispatcher principal ──────────────────────────────────────

    // Campos usados nas operações sem subcategoria (fora dos *Options), só pra exibir no histórico
    const topLevelFieldsForHistory = {
        sum:        [{ name: "numbers", label: "Números", type: "text" }],
        subtract:   [{ name: "numbers", label: "Números", type: "text" }],
        multiply:   [{ name: "value1", label: "Primeiro número" }, { name: "value2", label: "Segundo número" }],
        divide:     [{ name: "value1", label: "Primeiro número" }, { name: "value2", label: "Segundo número" }],
        bhaskara:   [{ name: "a", label: "Coeficiente A" }, { name: "b", label: "Coeficiente B" }, { name: "c", label: "Coeficiente C" }],
        hypotenuse: [{ name: "cateto1", label: "Primeiro cateto" }, { name: "cateto2", label: "Segundo cateto" }],
        log:        [{ name: "base", label: "Base do logaritmo", type: "text" }, { name: "logaritmando", label: "Logaritmando" }]
    };

    // Monta um resumo em texto das variáveis usadas numa operação, lendo os valores atuais do formulário
    function describeVariables(fields) {
        if (!fields || !fields.length) return "";
        return fields.map(f => {
            if (f.type === "matrix") {
                const cells = [];
                for (let i = 0; i < f.size * f.size; i++) cells.push(getFormValue(`${f.name}_${i}`) || "—");
                return `${f.label} = [${cells.join(", ")}]`;
            }
            const raw = getFormValue(f.name);
            if (f.type === "select") {
                const choice = f.choices?.find(c => c.value === raw);
                return `${f.label} = ${choice ? choice.label : (raw || "—")}`;
            }
            return `${f.label} = ${raw === "" ? "—" : raw}`;
        }).join(" · ");
    }

    // ── construtor de fórmulas modular (blocos clicáveis) ─────────────────────
    // O usuário monta uma expressão clicando em blocos (funções, operadores,
    // parênteses e valores), na ordem que quiser. Isso é convertido pra RPN
    // (notação polonesa reversa) e calculado respeitando a ordem das operações.

    function renderModularBuilder() {
        dynamicFields.innerHTML = `
            <div class="modular-builder">
                <div class="modular-preview empty" id="modular-preview">Clique nos blocos abaixo para montar sua expressão…</div>
                <div class="modular-palette">
                    <div class="modular-group">
                        <span class="modular-group-label">Funções</span>
                        <div class="modular-btn-row">
                            <button type="button" class="modular-btn func" data-token="sen">sen</button>
                            <button type="button" class="modular-btn func" data-token="cos">cos</button>
                            <button type="button" class="modular-btn func" data-token="tg">tg</button>
                            <button type="button" class="modular-btn func" data-token="cotg">cotg</button>
                            <button type="button" class="modular-btn func" data-token="arcsen">arcsen</button>
                            <button type="button" class="modular-btn func" data-token="arccos">arccos</button>
                            <button type="button" class="modular-btn func" data-token="arctg">arctg</button>
                        </div>
                    </div>
                    <div class="modular-group">
                        <span class="modular-group-label">Outras funções</span>
                        <div class="modular-btn-row">
                            <button type="button" class="modular-btn func" data-token="√">√</button>
                            <button type="button" class="modular-btn func" data-token="log">log</button>
                            <button type="button" class="modular-btn func" data-token="ln">ln</button>
                            <button type="button" class="modular-btn func" data-token="abs">abs</button>
                            <button type="button" class="modular-btn func" data-token="±">±</button>
                        </div>
                    </div>
                    <div class="modular-group">
                        <span class="modular-group-label">Operadores</span>
                        <div class="modular-btn-row">
                            <button type="button" class="modular-btn op" data-token="+">+</button>
                            <button type="button" class="modular-btn op" data-token="−">−</button>
                            <button type="button" class="modular-btn op" data-token="×">×</button>
                            <button type="button" class="modular-btn op" data-token="÷">÷</button>
                            <button type="button" class="modular-btn op" data-token="^">^</button>
                            <button type="button" class="modular-btn postfix" data-token="!">!</button>
                            <button type="button" class="modular-btn paren" data-token="(">(</button>
                            <button type="button" class="modular-btn paren" data-token=")">)</button>
                        </div>
                    </div>
                    <div class="modular-group modular-value-group">
                        <span class="modular-group-label">Valor</span>
                        <input type="text" inputmode="decimal" id="modular-value-input" class="modular-value-input" placeholder="Ex: 30">
                        <button type="button" id="modular-add-value" class="modular-btn value">Inserir valor</button>
                        <button type="button" class="modular-btn const" data-const="pi">π</button>
                        <button type="button" class="modular-btn const" data-const="e">e</button>
                    </div>
                </div>
                <div class="modular-actions">
                    <button type="button" id="modular-undo" class="modular-action-btn">Apagar último</button>
                    <button type="button" id="modular-clear" class="modular-action-btn">Limpar tudo</button>
                </div>
            </div>`;
        modularTokens = [];
        renderModularPreview();
    }

    function tokenDisplay(t) { return t.type === "num" ? (t.display || fmt(t.value)) : t.value; }

    function renderModularPreview() {
        const el = document.getElementById("modular-preview");
        if (!el) return;
        if (!modularTokens.length) {
            el.textContent = "Clique nos blocos abaixo para montar sua expressão…";
            el.classList.add("empty");
            return;
        }
        el.classList.remove("empty");
        el.textContent = modularTokens.map(tokenDisplay).join(" ");
    }

    // Adiciona um token; funções já vêm com o parêntese de abertura junto (sen → "sen(")
    function addModularToken(t) {
        modularTokens.push(t);
        if (t.type === "func") modularTokens.push({ type: "paren", value: "(" });
        renderModularPreview();
    }

    const MODULAR_PRECEDENCE = { "+": 2, "−": 2, "×": 3, "÷": 3, "^": 4 };
    const MODULAR_RIGHT_ASSOC = { "^": true };

    // Algoritmo shunting-yard: converte a sequência de tokens (como o usuário clicou)
    // pra notação polonesa reversa (RPN), respeitando precedência e parênteses.
    function modularToRPN(tokens) {
        const output = [];
        const opStack = [];
        for (const t of tokens) {
            if (t.type === "num") { output.push(t); continue; }
            if (t.type === "postfix") { output.push(t); continue; } // aplica direto no valor que já está na saída
            if (t.type === "func") { opStack.push(t); continue; }
            if (t.type === "paren" && t.value === "(") { opStack.push(t); continue; }
            if (t.type === "paren" && t.value === ")") {
                while (opStack.length && !(opStack[opStack.length - 1].type === "paren" && opStack[opStack.length - 1].value === "(")) {
                    output.push(opStack.pop());
                }
                if (!opStack.length) throw new Error("Parênteses desbalanceados.");
                opStack.pop(); // descarta o "("
                if (opStack.length && opStack[opStack.length - 1].type === "func") output.push(opStack.pop());
                continue;
            }
            // operador binário
            while (opStack.length) {
                const top = opStack[opStack.length - 1];
                if (top.type === "paren") break;
                const topPrec = top.type === "func" ? 5 : MODULAR_PRECEDENCE[top.value];
                if (topPrec > MODULAR_PRECEDENCE[t.value] || (topPrec === MODULAR_PRECEDENCE[t.value] && !MODULAR_RIGHT_ASSOC[t.value])) {
                    output.push(opStack.pop());
                } else break;
            }
            opStack.push(t);
        }
        while (opStack.length) {
            const top = opStack.pop();
            if (top.type === "paren") throw new Error("Parênteses desbalanceados.");
            output.push(top);
        }
        return output;
    }

    // Avalia a expressão em RPN com uma pilha, registrando cada operação como um passo
    function modularEvalRPN(rpn) {
        const stack = [];
        const stepsLog = [];
        for (const t of rpn) {
            if (t.type === "num") { stack.push(t.value); continue; }
            if (t.type === "postfix") {
                const a = stack.pop();
                if (a === undefined) throw new Error("Expressão inválida.");
                if (t.value === "!") {
                    if (a < 0 || !Number.isInteger(a)) throw new Error("Fatorial requer um número inteiro ≥ 0.");
                    if (a > 170) throw new Error("Número muito grande para calcular o fatorial.");
                    const r = factorial(a);
                    stepsLog.push(`${fmt(a)}! = ${fmt(r)}`);
                    stack.push(r);
                }
                continue;
            }
            if (t.type === "func") {
                const a = stack.pop();
                if (a === undefined) throw new Error("Expressão inválida.");
                let r;
                if (t.value === "sen") r = Math.sin(a * Math.PI / 180);
                else if (t.value === "cos") r = Math.cos(a * Math.PI / 180);
                else if (t.value === "tg") { if (Math.abs(Math.cos(a * Math.PI / 180)) < 1e-9) throw new Error("tg indefinida para esse ângulo."); r = Math.tan(a * Math.PI / 180); }
                else if (t.value === "cotg") { if (Math.abs(Math.sin(a * Math.PI / 180)) < 1e-9) throw new Error("cotg indefinida para esse ângulo."); r = 1 / Math.tan(a * Math.PI / 180); }
                else if (t.value === "arcsen") { if (a < -1 || a > 1) throw new Error("arcsen só aceita valores entre -1 e 1."); r = Math.asin(a) * 180 / Math.PI; }
                else if (t.value === "arccos") { if (a < -1 || a > 1) throw new Error("arccos só aceita valores entre -1 e 1."); r = Math.acos(a) * 180 / Math.PI; }
                else if (t.value === "arctg") r = Math.atan(a) * 180 / Math.PI;
                else if (t.value === "√") { if (a < 0) throw new Error("Raiz de número negativo."); r = Math.sqrt(a); }
                else if (t.value === "log") { if (a <= 0) throw new Error("log só aceita valores maiores que 0."); r = Math.log10(a); }
                else if (t.value === "ln") { if (a <= 0) throw new Error("ln só aceita valores maiores que 0."); r = Math.log(a); }
                else if (t.value === "abs") r = Math.abs(a);
                else if (t.value === "±") r = -a;
                stepsLog.push(`${t.value}(${fmt(a)}) = ${fmt(r)}`);
                stack.push(r);
                continue;
            }
            const b = stack.pop(), a = stack.pop();
            if (a === undefined || b === undefined) throw new Error("Expressão inválida — confira se todo operador tem dois valores.");
            let r;
            if (t.value === "+") r = a + b;
            else if (t.value === "−") r = a - b;
            else if (t.value === "×") r = a * b;
            else if (t.value === "÷") { if (b === 0) throw new Error("Divisão por zero."); r = a / b; }
            else if (t.value === "^") r = a ** b;
            stepsLog.push(`${fmt(a)} ${t.value} ${fmt(b)} = ${fmt(r)}`);
            stack.push(r);
        }
        if (stack.length !== 1) throw new Error("Expressão inválida (confira parênteses e operadores).");
        return { value: stack[0], stepsLog };
    }

    function calculateModular() {
        if (!modularTokens.length) return "Monte uma expressão clicando nos blocos.";
        const exprDisplay = modularTokens.map(tokenDisplay).join(" ");
        try {
            const rpn = modularToRPN(modularTokens);
            const { value, stepsLog } = modularEvalRPN(rpn);
            st(`Expressão montada: ${exprDisplay}`);
            stepsLog.forEach(s => st(s));
            return `Valor calculado: ${fmt(value)}`;
        } catch (err) {
            return `Erro na expressão "${exprDisplay}": ${err.message}`;
        }
    }

    function calculate() {
        const type = calcType.value;
        const subtypeKey = {
            finance:       "financeType",
            electrical:    "electricalType",
            physics:       "physicsType",
            progression:   "progressionType",
            geometry:      "geometryType",
            engineering:   "engineeringType",
            trigonometry:  "trigonometryType",
            statistics:    "statisticsType",
            combinatorics: "combinatoricsType",
            matrices:      "matricesType",
            units:         "unitsType"
        };
        const sub = subtypeKey[type];
        const op = sub ? (form.elements[sub]?.value || "") : "";

        let result;
        // get operation description for history
        let opDesc = labels[type] || type;
        const optMap = {
            finance: financeOptions,
            electrical: electricalOptions,
            physics: physicsOptions,
            progression: progressionOptions,
            geometry: geometryOptions,
            engineering: engineeringOptions,
            trigonometry: trigonometryOptions,
            statistics: statisticsOptions,
            combinatorics: combinatoricsOptions,
            matrices: matricesOptions,
            units: unitsOptions
        };
        if (op) {
            const map = optMap[type];
            if (map && map[op]) opDesc = map[op].title;
        }
        // Por padrão nenhum gráfico é mostrado; só os tipos com gráfico associado o reativam abaixo
        hideChart();
        lastSteps = [];

        switch (type) {
            case "sum": {
                const raw = getFormValue("numbers");
                const nums = parseNumbers(raw);
                if (nums.length < 2) result = "Informe ao menos 2 números.";
                else {
                    st(`Fórmula: soma = n₁ + n₂ + ... + nₙ`);
                    st(`Expressão: ${nums.map(fmt).join(" + ")}`);
                    let acc = nums[0];
                    for (let i = 1; i < nums.length; i++) {
                        const next = acc + nums[i];
                        st(`${fmt(acc)} + ${fmt(nums[i])} = ${fmt(next)}`);
                        acc = next;
                    }
                    result = `Soma: ${fmt(acc)}`;
                }
                break;
            }
            case "subtract": {
                const raw = getFormValue("numbers");
                const nums = parseNumbers(raw);
                if (nums.length < 2) result = "Informe ao menos 2 números.";
                else {
                    st(`Fórmula: resultado = n₁ − n₂ − ... − nₙ`);
                    st(`Expressão: ${nums.map(fmt).join(" − ")}`);
                    let acc = nums[0];
                    for (let i = 1; i < nums.length; i++) {
                        const next = acc - nums[i];
                        st(`${fmt(acc)} − ${fmt(nums[i])} = ${fmt(next)}`);
                        acc = next;
                    }
                    result = `Subtração: ${fmt(acc)}`;
                }
                break;
            }
            case "multiply": {
                const a=rn("value1"), b=rn("value2");
                if(a===null||b===null) result = "Preencha ambos os campos.";
                else {
                    st(`Fórmula: produto = a × b`);
                    st(`Substituindo: produto = ${fmt(a)} × ${fmt(b)}`);
                    result = `Multiplicação: ${fmt(a*b)}`;
                }
                break;
            }
            case "divide": {
                const a=rn("value1"), b=rn("value2");
                if(a===null||b===null) result = "Preencha ambos os campos.";
                else if(b===0) result = "Divisão por zero!";
                else {
                    st(`Fórmula: quociente = a ÷ b`);
                    st(`Substituindo: quociente = ${fmt(a)} ÷ ${fmt(b)}`);
                    result = `Divisão: ${fmt(a/b)}`;
                }
                break;
            }
            case "bhaskara": {
                const a=rn("a"), b=rn("b"), c_=rn("c");
                if(a===null||b===null||c_===null) result = "Preencha todos os coeficientes.";
                else if(a===0) result = "A não pode ser 0 (equação de 1º grau).";
                else {
                    const delta = b*b - 4*a*c_;
                    st(`Fórmula: Δ = b² − 4ac`);
                    st(`Substituindo: Δ = (${fmt(b)})² − 4×${fmt(a)}×${fmt(c_)} = ${fmt(b*b)} − ${fmt(4*a*c_)}`);
                    st(`Δ = ${fmt(delta)}`);
                    if(delta < 0) {
                        st(`Como Δ < 0, a equação não tem raízes reais.`);
                        result = "Δ < 0 — sem raízes reais.";
                    } else {
                        st(`Fórmula: x = (−b ± √Δ) / (2a)`);
                        const raizDelta = Math.sqrt(delta);
                        st(`Substituindo: x = (−(${fmt(b)}) ± √${fmt(delta)}) / (2×${fmt(a)}) = (${fmt(-b)} ± ${fmt(raizDelta)}) / ${fmt(2*a)}`);
                        const x1 = (-b + raizDelta)/(2*a);
                        const x2 = (-b - raizDelta)/(2*a);
                        st(`x' = (${fmt(-b)} + ${fmt(raizDelta)}) / ${fmt(2*a)} = ${fmt(x1)}`);
                        st(`x'' = (${fmt(-b)} − ${fmt(raizDelta)}) / ${fmt(2*a)} = ${fmt(x2)}`);
                        result = `Δ = ${fmt(delta)}\nx' = ${fmt(x1)}\nx'' = ${fmt(x2)}`;
                    }
                    chartBhaskara(a, b, c_, delta);
                }
                break;
            }
            case "hypotenuse": {
                const c1=rn("cateto1"), c2=rn("cateto2");
                if(c1===null||c2===null) result = "Preencha ambos os catetos.";
                else {
                    st(`Fórmula: h = √(cateto1² + cateto2²)`);
                    st(`Substituindo: h = √((${fmt(c1)})² + (${fmt(c2)})²) = √(${fmt(c1*c1)} + ${fmt(c2*c2)})`);
                    st(`h = √${fmt(c1*c1+c2*c2)}`);
                    result = `Hipotenusa: ${fmt(Math.sqrt(c1*c1+c2*c2))}`;
                }
                break;
            }
            case "log": {
                const base = getFormValue("base");
                const val = rn("logaritmando");
                if(val===null||val<=0) result = "Logaritmando > 0.";
                else if(base==="e") {
                    st(`Fórmula: ln(x) = logaritmo natural (base e) de x`);
                    st(`Substituindo: ln(${fmt(val)})`);
                    result = `ln(${fmt(val)}) = ${fmt(Math.log(val))}`;
                } else {
                    const b = Number(base);
                    if(Number.isNaN(b)||b<=0||b===1) result = "Base inválida.";
                    else {
                        st(`Fórmula: log_{base}(x) = ln(x) / ln(base) (troca de base)`);
                        st(`Substituindo: log_{${base}}(${fmt(val)}) = ln(${fmt(val)}) / ln(${base}) = ${fmt(Math.log(val))} / ${fmt(Math.log(b))}`);
                        result = `log_{${base}}(${fmt(val)}) = ${fmt(Math.log(val)/Math.log(b))}`;
                    }
                }
                break;
            }
            case "finance":       result = calculateFinance(op); break;
            case "electrical":    result = calculateElectrical(op); break;
            case "physics":       result = calculatePhysics(op); break;
            case "progression":   result = calculateProgression(op); break;
            case "geometry":      result = calculateGeometry(op); break;
            case "engineering":   result = calculateEngineering(op); break;
            case "trigonometry":  result = calculateTrig(op); break;
            case "statistics":    result = calculateStatistics(op); break;
            case "combinatorics": result = calculateCombinatorics(op); break;
            case "matrices":      result = calculateMatrices(op); break;
            case "units":         result = calculateUnits(op); break;
            case "modular":       result = calculateModular(); break;
            default: result = "Tipo de cálculo desconhecido.";
        }

        // Se alguma função registrou passos de resolução, fecha com a linha do resultado final
        // e busca a explicação teórica correspondente (mostrada sempre visível, acima do botão)
        lastTheory = lastSteps.length ? theoryFor(type, op) : "";
        if (lastSteps.length) lastSteps.push(`Resultado: ${result}`);

        // Save to localStorage history
        const varsFields = (op && optMap[type] && optMap[type][op]) ? optMap[type][op].fields : (topLevelFieldsForHistory[type] || null);
        const historyVars = type === "modular" ? modularTokens.map(tokenDisplay).join(" ") : describeVariables(varsFields);
        saveToHistory(opDesc, result, historyVars);

        logCode(1, opDesc);
        return result;
    }

    // ── sistema de histórico (localStorage) ──────────────────────

    const HISTORY_KEY = "calcHistory";

    function loadHistory() {
        try {
            const data = localStorage.getItem(HISTORY_KEY);
            return data ? JSON.parse(data) : [];
        } catch { return []; }
    }

    function saveToHistory(type, result, variables = "") {
        const history = loadHistory();
        const entry = {
            id: Date.now(),
            date: new Date().toLocaleString("pt-BR"),
            type: type,
            result: result,
            variables: variables
        };
        history.unshift(entry); // most recent first
        // keep max 100 entries
        if (history.length > 100) history.length = 100;
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
        logCode(2, type);
        renderHistory();
    }

    function renderHistory() {
        const listEl = document.getElementById("history-list");
        if (!listEl) return;
        const history = loadHistory();
        if (history.length === 0) {
            listEl.innerHTML = '<p class="history-empty">Nenhum cálculo realizado ainda.</p>';
            logCode(3, "0 itens");
            return;
        }
        listEl.innerHTML = history.map(e => `
            <div class="history-item">
                <div class="h-date">${e.date}</div>
                <div class="h-type">${escapeHtml(e.type)}</div>
                <div class="h-result">${escapeHtml(e.result)}</div>
                ${e.variables ? `
                <button type="button" class="h-vars-toggle" data-id="${e.id}" aria-expanded="false">Ver variáveis</button>
                <div class="h-vars" data-id="${e.id}">${escapeHtml(e.variables)}</div>
                ` : ""}
            </div>
        `).join("");
        logCode(3, `${history.length} ${history.length === 1 ? "item" : "itens"}`);
    }

    function clearHistory() {
        localStorage.removeItem(HISTORY_KEY);
        logCode(4);
        renderHistory();
    }

    function escapeHtml(str) {
        const div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }

    // ── event listeners ──────────────────────────────────────────

    calcType.addEventListener("change", () => {
        renderFields();
        logCode(5, labels[calcType.value] || calcType.value);
    });
    form.addEventListener("change", (e) => {
        if(["financeType","electricalType","physicsType","progressionType","geometryType","engineeringType",
            "trigonometryType","statisticsType","combinatoricsType","matricesType","unitsType"].includes(e.target.name)) {
            renderFields();
            logCode(5, e.target.name);
        }
    });
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        const resultText = calculate();
        resultBox.textContent = resultText;
        renderTheory(lastTheory);
        renderSteps(lastSteps);
        // reinicia a animação de entrada (retira e força reflow antes de reaplicar a classe)
        resultBox.classList.remove("pop");
        theoryEl?.classList.remove("pop");
        void resultBox.offsetWidth;
        resultBox.classList.add("pop");
        if (!theoryEl?.hidden) theoryEl?.classList.add("pop");

        // botão de ouvir resultado (só some se o navegador não tiver Web Speech API)
        const speakBtn = document.getElementById("speak-result");
        if (speakBtn) {
            if ("speechSynthesis" in window) {
                speakBtn.hidden = false;
                speakBtn.onclick = () => speakText(resultText);
                if (a11ySettings.autoSpeak) speakText(resultText);
            } else {
                speakBtn.hidden = true;
            }
        }
    });

    // clear history button + toggle do passo a passo + toggle das variáveis no histórico
    document.addEventListener("click", (e) => {
        if (e.target.id === "clear-history") clearHistory();
        if (e.target.id === "toggle-steps" && stepsListEl) {
            const willOpen = !stepsListEl.classList.contains("open");
            stepsListEl.classList.toggle("open", willOpen);
            e.target.textContent = willOpen ? "Ocultar passo a passo" : "Ver passo a passo";
            e.target.setAttribute("aria-expanded", String(willOpen));
        }
        if (e.target.classList.contains("h-vars-toggle")) {
            const id = e.target.dataset.id;
            const panel = document.querySelector(`.h-vars[data-id="${id}"]`);
            if (panel) {
                const willOpen = !panel.classList.contains("open");
                panel.classList.toggle("open", willOpen);
                e.target.textContent = willOpen ? "Ocultar variáveis" : "Ver variáveis";
                e.target.setAttribute("aria-expanded", String(willOpen));
            }
        }
        // construtor de fórmulas modular: blocos de função/operador/parêntese
        const tokenBtn = e.target.closest(".modular-btn[data-token]");
        if (tokenBtn) {
            const val = tokenBtn.dataset.token;
            if (tokenBtn.classList.contains("func")) addModularToken({ type: "func", value: val });
            else if (tokenBtn.classList.contains("op")) addModularToken({ type: "op", value: val });
            else if (tokenBtn.classList.contains("paren")) addModularToken({ type: "paren", value: val });
            else if (tokenBtn.classList.contains("postfix")) addModularToken({ type: "postfix", value: val });
        }
        // constantes prontas (π e e)
        const constBtn = e.target.closest(".modular-btn[data-const]");
        if (constBtn) {
            const c = constBtn.dataset.const;
            if (c === "pi") addModularToken({ type: "num", value: Math.PI, display: "π" });
            else if (c === "e") addModularToken({ type: "num", value: Math.E, display: "e" });
        }
        if (e.target.id === "modular-add-value") {
            const input = document.getElementById("modular-value-input");
            const raw = input?.value.trim().replace(",", ".");
            const num = Number(raw);
            if (raw && !Number.isNaN(num)) {
                addModularToken({ type: "num", value: num });
                input.value = "";
                input.focus();
            }
        }
        if (e.target.id === "modular-undo" && modularTokens.length) {
            const last = modularTokens[modularTokens.length - 1];
            // se o último for o "(" que uma função auto-inseriu, apaga os dois juntos
            if (last.type === "paren" && last.value === "(" && modularTokens.length >= 2 && modularTokens[modularTokens.length - 2].type === "func") {
                modularTokens.splice(-2, 2);
            } else {
                modularTokens.pop();
            }
            renderModularPreview();
        }
        if (e.target.id === "modular-clear") {
            modularTokens = [];
            renderModularPreview();
        }

        // painel de acessibilidade: abrir/fechar
        const a11yToggle = document.getElementById("a11y-toggle");
        const a11yPanel = document.getElementById("a11y-panel");
        const a11yClose = document.getElementById("a11y-close");
        if (e.target.closest("#a11y-toggle")) {
            const willOpen = a11yPanel.hidden;
            a11yPanel.hidden = !willOpen;
            a11yToggle.setAttribute("aria-expanded", String(willOpen));
        }
        if (e.target.closest("#a11y-close")) {
            a11yPanel.hidden = true;
            a11yToggle.setAttribute("aria-expanded", "false");
        }
        // fecha o painel clicando fora dele (mas não no botão que abre)
        if (!e.target.closest("#a11y-panel") && !e.target.closest("#a11y-toggle") && a11yPanel && !a11yPanel.hidden) {
            a11yPanel.hidden = true;
            a11yToggle?.setAttribute("aria-expanded", "false");
        }
        // opções de tema / tamanho da fonte
        const a11yOption = e.target.closest(".a11y-option[data-setting]");
        if (a11yOption) {
            a11ySettings[a11yOption.dataset.setting] = a11yOption.dataset.value;
            saveA11ySettings();
        }
    });

    // toggles (reduzir animações / falar automaticamente)
    document.addEventListener("change", (e) => {
        if (e.target.id === "a11y-reduced-motion") {
            a11ySettings.reducedMotion = e.target.checked;
            saveA11ySettings();
        }
        if (e.target.id === "a11y-auto-speak") {
            a11ySettings.autoSpeak = e.target.checked;
            saveA11ySettings();
        }
    });

    // Enter no campo de valor do construtor modular insere o valor, sem submeter o formulário
    document.addEventListener("keydown", (e) => {
        if (e.target.id === "modular-value-input" && e.key === "Enter") {
            e.preventDefault();
            document.getElementById("modular-add-value")?.click();
        }
    });

    // load history on page load
    applyA11ySettings();
    renderHistory();
    renderFields();
    logCode(6, "carregamento inicial da página");
});
